
window.onerror = function(message, source, lineno, colno, error) {
    console.log('捕获到异常：',{message, source, lineno, colno, error});
 }

function initJiaogeiwo(t) {
    // jiaogeiwo变量
    const jiaogeiwo_vars = {
        project: '',
        dir: '',
        origin: '',
    }
    // http请求相关
    const jiaogeiwo_http = {
        get: (url, {showLoading = false, showError = true, showSuccess = false} = {}) => {
            showLoading && $.blockUI({
                message: '<div class="spinner-border text-white" role="status"></div>',
                css: {
                    backgroundColor: 'transparent',
                    border: '0'
                },
                overlayCSS: {
                    opacity: 0.5
                }
            });
            const token = localStorage.getItem('token');
            return fetch(url.indexOf('http') === 0 ? url : `${jiaogeiwo.vars.origin}/api/admin/md/${jiaogeiwo.vars.dir}/${jiaogeiwo.vars.project}/${url}`, {
                    headers: {
                        Authorization: token
                    },
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 0) {
                        showSuccess && toastr['success']('', data.message || i18next.t('保存成功'), {
                            positionClass: 'toast-top-center',
                            showMethod: 'slideDown',
                            hideMethod: 'slideUp',
                            closeButton: true,
                            tapToDismiss: false,
                            rtl: false
                        });
                        return data;
                    }
                    if (data.status === -1 && data.message === '无效的token') { // 会员token
                        localStorage.setItem('lastpath', location.pathname + location.search);
                        location.href = '/member/auth/login.html';
                    }
                    if (data.statusCode === 401 && data.message === 'Invalid token') { // 超级管理员token
                        location.href = location.protocol + '//' + location.hostname.replace('.temp', '') + '/icenter';
                    }
                    showError && toastr['error'](i18next.t(data.message) || data.message, i18next.t('错误'), {
                        positionClass: 'toast-top-center',
                        showMethod: 'slideDown',
                        hideMethod: 'slideUp',
                        closeButton: true,
                        tapToDismiss: false,
                        rtl: false
                    });
                    return Promise.reject(data);
                })
                .finally(() => {
                    console.info('finally')
                    showLoading && $.unblockUI();
                })
        },
        post: (url, data = {}, {showLoading = true, showError = true, showSuccess = true} = {}) => {
            showLoading && $.blockUI({
                message: '<div class="spinner-border text-white" role="status"></div>',
                css: {
                    backgroundColor: 'transparent',
                    border: '0'
                },
                overlayCSS: {
                    opacity: 0.5
                }
            });
            const token = localStorage.getItem('token');
            return fetch(url.indexOf('http') === 0 ? url : `${jiaogeiwo.vars.origin}/api/admin/md/${jiaogeiwo.vars.dir}/${jiaogeiwo.vars.project}/${url}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: token
                },
                body: JSON.stringify(data)
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 0) {
                    showSuccess && toastr['success']('', data.message || i18next.t('保存成功'), {
                        positionClass: 'toast-top-center',
                        showMethod: 'slideDown',
                        hideMethod: 'slideUp',
                        closeButton: true,
                        tapToDismiss: false,
                        rtl: false
                    });
                    return data;
                }
                if (data.status === -1 && data.message === '无效的token') {
                    localStorage.setItem('lastpath', location.pathname + location.search);
                    location.href = '/member/auth/login.html';
                }
                if (data.statusCode === 401 && data.message === 'Invalid token') { // 超级管理员token
                    location.href = location.protocol + '//' + location.hostname.replace('.temp', '') + '/icenter';
                }
                showError && toastr['error'](i18next.t(data.message) || data.message, i18next.t('错误'), {
                    positionClass: 'toast-top-center',
                    showMethod: 'slideDown',
                    hideMethod: 'slideUp',
                    closeButton: true,
                    tapToDismiss: false,
                    rtl: false
                });
                return Promise.reject(data);
            })
            .finally(() => {
                console.info('finally')
                showLoading && $.unblockUI();
            })
        }
    };
    // 通用代码，复用
    const jiaogeiwo_common = {
        del: (promise) => {
            return Swal.fire({
                title: `${i18next.t('您确定吗')}?`,
                text: `${i18next.t('您将无法还原此内容')}！`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: `${i18next.t('是的')}, ${i18next.t('删除它')}!`,
                cancelButtonText: `${i18next.t('取消')}!`,
                customClass: {
                confirmButton: 'btn btn-primary',
                cancelButton: 'btn btn-outline-danger ml-1'
                },
                buttonsStyling: false
            }).then((result) => {
                if (result.value) {
                    return promise
                        .then((data) => {
                            Swal.fire({
                                icon: 'success',
                                title: `${i18next.t('删除了')}!`,
                                text: `${i18next.t('这条数据已经删除成功')}.`,
                                customClass: {
                                    confirmButton: 'btn btn-success'
                                }
                            });
                            return data;
                        })
                }
                return Promise.resolve();
            });
        }
    }
    // 增删改查table
    const jiaogeiwo_table = {
        init: function (name, {
            moduleName = '', // 模块名称
            is_filter = true, // 筛选条件
            is_search = true, // 模糊查询
            is_add = true, // 新增
            is_add_upload = true, // 新增导入
            is_edit = true,
            is_multi = true, // 多选
            multi_more = [], // 额外的多选功能
            is_operation = true, // 是否需要操作
            operations_main = [], // 操作额外的main功能
            operations_more = [], // 操作额外的more功能
            page_index = 1, // 默认显示第一页
            page_size = 10, // 默认一页显示数量
            sort_name = 'create_time', // 排序名称
            sort_type = -1, // 排序正倒叙 1, -1
            detail_width = '50vw', // 编辑框默认的宽度
            unique_index = [], // 表单的唯一字段索引
            params_extra = {}, // 额外的查询参数
            footer_html = '', // 底部描述内容
            upload_dir_default = {type: 'document', name: 'title', content: 'content'},
            del_intro = (event) => {
                return `${i18next.t('您将无法还原此内容')}！`
            },
            operations = { // 操作列表
                main: [
                    (item) => `<a class="pr-1 item-edit" uid=${item._id} href="javascript:void(0);">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit font-small-4"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>
                        <span>${i18next.t('编辑')}</span>
                    </a>`,
                    (item) => `<a class="pr-1 item-copy" uid=${item._id} href="javascript:void(0);">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-copy"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
                        <span>${i18next.t('复制')}</span>
                    </a>`
                ],
                more: [
                    (item) => `<a class="dropdown-item item-view" uid=${item._id} href="javascript:void(0);">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-eye font-small-4 mr-50"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                        <span>${i18next.t('查看')}</span>
                    </a>`,
                    (item) => `<a class="dropdown-item item-del" uid=${item._id} uname="${item.name}" href="javascript:void(0);">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash font-small-4 mr-50"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
                        <span>${i18next.t('删除')}</span>
                    </a>`
                ]
            },
            columns = [], // 列
            api = {
                list: `${name}-list`,
                delete: `${name}-delete`,
                deletes: `${name}-deletes`,
                deleteAll: `${name}-deleteAll`,
                adds: `${name}-adds?unique_index=${unique_index}`,
                add: `${name}-add?unique_index=${unique_index}`,
                update: `${name}-update?unique_index=${unique_index}`,
                updates: `${name}-updates?unique_index=${unique_index}`,
                detail: `${name}-detail`
            },
            customEvent = { // 数据接口的回调函数
                'list-event': () => {},
                'delete-event': () => {},
                'deletes-event': () => {},
                'deleteAll-event': () => {},
                'adds-event': () => {},
                'add-event': () => {},
                'update-event': () => {},
                'detail-event': () => {},
            },
            functions = { // 可以重写一些功能函数
                downloadExcel: null
            }
        } = {}) {
            // 列表内容
            const default_column = {
                type: 'text', // 字段类型: text、textarea...
                is_show: true, // 是否列表显示
                is_edit: true, // 是否可编辑
                is_search: true, // 是否支持模糊搜索
                is_filter: false, // 是否支持筛选
                is_upload_dir: false, // 批量导入文件夹
                valid_rule: {
                    required: true // 是否必填,
                },
                detail_class: 'col-md-6 col-12' // 详情的布局容器
            }
            columns = columns.map(column => {
                return {...default_column, ...column};
            });

            let pagination = {index: page_index, size: page_size, all_count: 0};
            let params = {extra: Object.keys(params_extra).filter(key => !!params_extra[key]).reduce((prev, curr) => ({...prev, [curr]: params_extra[curr]}), {})};
            let deletes = {};

            function pageChange(event, page) {
                if (page !== pagination.index) {
                    pagination.index = page;
                    updateListByPage();
                }
            }
            jiaogeiwo_table.updateList = updateList = function() {
                return getList().then(({list_content, page_content}) => {
                    $(`#${name} table tbody`).replaceWith(list_content);
                    $(`#${name} table tfoot`).replaceWith(page_content);
                })
            }
            function updateListByPage() {
                return getList().then(({list_content, page_content}) => {
                    $(`#${name} table tbody`).replaceWith(list_content);
                })
            }
            function getList() {
                return jiaogeiwo.http.post(`${api.list}?index=${pagination.index}&size=${pagination.size}&sortName=${sort_name}&sortType=${sort_type}`, params, {showSuccess: false})
                    .then((data) => {
                        pagination.all_count = data.count;
                        // custom event
                        if (typeof customEvent['list-event'] === 'function') {
                            customEvent['list-event'](data);
                        }
                        let list_content = '';
                        let page_content = '';
                        if ((data.list || []).length === 0) {
                            list_content = `<tbody><tr><td colspan="${columns.length + (is_multi ? 1 : 0) + (is_operation ? 1 : 0)}" align="center">${i18next.t('暂无数据')}！</td></tr></tbody>`
                            page_content = '<tfoot></tfoot>'
                        } else {
                            list_content = `<tbody>${(data.list || []).map((item, index) => {
                                return `
                                    <tr>
                                        ${is_multi ? `<td>
                                            <div class="custom-control custom-checkbox"> 
                                                <input class="custom-control-input dt-checkboxes item-checkbox" type="checkbox" id="item-checkbox${index}" uid=${item._id} ${deletes[item._id] ? 'checked' : ''}>
                                                <label class="custom-control-label" for="item-checkbox${index}"></label>
                                            </div>
                                        </td>` : ''}
                                        ${columns.filter(column => column.is_show).map((column) => {
                                            if (typeof column.list_render === 'function') return column.list_render(item, column, columns);
                                            if (column.type === 'datetime-local') {
                                                item[column.name] = new Date(item[column.name]).toLocaleString();
                                            }
                                            if (column.type === 'date-range') {
                                                item[column.name] = item[column.name] ? item[column.name].text : '';
                                            }
                                            if (column.type === 'file') {
                                                const urls = item[column.name] || '';
                                                return `<td>${urls ? urls.map(item => 
                                                    `<a href="${item + '?response-content-type=application%2Foctet-stream'}" target="_blank">${item.substring(item.lastIndexOf('/') + 1)}<svg style="margin-left: 8px;" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-download"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg></a>`
                                                ).join('') : '-'}</td>`
                                            }
                                            if (column.type === 'single_file') {
                                                const value = item[column.name] || '';
                                                return `<td>
                                                    ${value ? `<a href="${value + '?response-content-type=application%2Foctet-stream'}" target="_blank">${value.substring(value.lastIndexOf('/') + 1)}<svg style="margin-left: 8px;" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-download"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg></a>` : ''}
                                                </td>`
                                            }
                                            if (column.type === 'checkbox') {
                                                let values = item[column.name] || [];
                                                return `<td>
                                                    ${(values instanceof Array ? values : values.split(',')).map(value => {
                                                        const valueObj = column.data.find(it => (typeof it === 'object') ? (it.value === value) : (it === value)) || {name: value};
                                                        return `<span class="badge badge-pill badge-light-primary">${i18next.t(valueObj.name || value)}</span>`
                                                    }).join(' ')}
                                                </td>`;
                                            }
                                            if (column.type === 'select') {
                                                let values = item[column.name];
                                                if (['string', 'number'].includes(typeof item[column.name])) {
                                                    values = [item[column.name]];
                                                }
                                                if (column.is_alone_edit) {
                                                    return `<td>
                                                        <a class="item-alone-edit" uid="${item._id}" column_name="${column.name}" value="${values}" href="javascript:void(0);">
                                                            <span>${(values || []).map(value => {
                                                                const valueObj = column.data.find(it => (typeof it === 'object') ? (it.value === value) : (it === value)) || {name: value};
                                                                return `<span>${i18next.t(valueObj.name || valueObj)}</span>`
                                                            }).join('<span class="mx-1">·</span>')}</span>
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>
                                                        </a>
                                                    </td>`;
                                                }
                                                return `<td>
                                                    ${(values || []).map(value => {
                                                        const valueObj = column.data.find(it => (typeof it === 'object') ? (it.value === value) : (it === value)) || {name: value};
                                                        return `<span class="badge badge-pill badge-light-primary">${i18next.t(valueObj.name || value)}</span>`
                                                    }).join(' ')}
                                                </td>`;
                                            }
                                            if (column.type === 'provinces') {
                                                let value = item[column.name] || {};
                                                return `<td>
                                                    ${Object.keys(value).map(key => {
                                                        return `<span class="badge badge-pill badge-light-primary">${i18next.t(value[key])}</span>`
                                                    }).join(' ')}
                                                </td>`;
                                            }
                                            if (column.type === 'image') {
                                                return `
                                                    <td>
                                                        ${item[column.name] ? `<div class="avatar-group">
                                                            <a class="avatar pull-up" href="${item[column.name]}" target="_blank">
                                                                <img src="${item[column.name]}" height="32" width="32" style="object-fit: cover;">
                                                            </a>
                                                        </div>` : '-'}
                                                    </td>
                                                `
                                            }
                                            if (column.type === 'images') {
                                                const urls = item[column.name] || '';
                                                return `
                                                    <td>
                                                        ${urls ? `<div class="avatar-group">
                                                            ${(typeof urls === 'string' ? urls.split(',') : urls).map(item => `
                                                                <a class="avatar pull-up" href="${item}" target="_blank">
                                                                    <img src="${item.indexOf('.mp4') !== -1 ? `${item}?x-oss-process=video/snapshot,t_1000` : item}" height="32" width="32" style="object-fit: cover;">
                                                                </a>
                                                            `).join('')}
                                                        </div>` : '-'}
                                                    </td>
                                                `
                                            }
                                            if (column.type === 'repeater') {
                                                const values = item[column.name];
                                                return `
                                                    <td>
                                                        ${values instanceof Array ? values.map(item => {
                                                            return `<p>${Object.keys(item).map(key => {
                                                                if (typeof (item[key]) === 'string' && item[key].indexOf('//') === 0) { // 链接
                                                                    if(['jpg','jpeg','ico','.gif','svg','.webp','.png'].some(suffix => item[key].toLowerCase().endsWith(suffix))){
                                                                        return `<a class="avatar pull-up" href="${item[key]}" target="_blank">
                                                                            <img src="${item[key]}" height="20" width="20" style="object-fit: cover;">
                                                                        </a>`
                                                                    }                                                              
                                                                    return `<a href="${item[key]}" target="_blank">${item[key].substring(item[key].lastIndexOf('/') + 1)}</a>`
                                                                }
                                                                return item[key];
                                                            }).join(' | ')}</p>`
                                                        }).join('') : '-'}
                                                    </td>
                                                `;
                                            }
                                            if (column.ignore_i18n) {
                                                return `<td>${item[column.name] || '-'}</td>`;
                                            }
                                            return `<td>${i18next.exists('' + item[column.name]) ? i18next.t(item[column.name]) : (item[column.name] || '-')}</td>`;
                                        }).join('\n')}
                                        ${is_operation ? `<td>
                                            <div class="d-inline-flex">
                                            ${[...(operations.main || []), ...(operations_main || [])].map(fn => fn(item)).join('')}
                                                ${(operations.more || []).length > 0 ? `<a class="dropdown-toggle hide-arrow text-primary" data-toggle="dropdown">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical font-small-4"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle></svg>
                                                    <div class="dropdown-menu dropdown-menu-right">
                                                        ${[...(operations.more || []), ...(operations_more || [])].map(fn => fn(item)).join('')}
                                                    </div>
                                                </a>` : ''}
                                            </div>
                                        </td>` : ''}
                                    </tr>
                                `;
                            }).join('\n')}</tbody>`;
                            page_content = `
                                <tfoot>
                                    <tr>
                                        <th colspan="${columns.filter(item => item.is_show).length + (is_multi ? 1 : 0) + (is_operation ? 1 : 0)}">
                                            <div style="display: flex;align-items: center;justify-content: space-between;">
                                                <div class="pagination-total">${i18next.t('显示{{count}}个条目中的{{start}}到{{end}}个', {count: data.count, start: (pagination.index - 1) * pagination.size + 1, end: Math.min(data.count, pagination.index * pagination.size)})}</div>
                                                <div><ul class="pagination mb-0"></ul></div>
                                            </div>
                                        </th>
                                    </tr>
                                    <script>
                                        $('#${name} .pagination').twbsPagination({
                                            totalPages: ${Math.ceil(data.count / pagination.size)},
                                            visiblePages: 5,
                                            prev: '${i18next.t('上一页')}',
                                            next: '${i18next.t('下一页')}',
                                            first: '${i18next.t('第一页')}',
                                            last: '${i18next.t('最后一页')}',
                                            startPage: ${pagination.index},
                                            initiateStartPageClick: false,
                                            onPageClick: function (event, page) {
                                                window['${name}Table'] && window['${name}Table'].pageChange(event, page);
                                                $('#${name} .pagination-total').text(i18next.t('显示{{count}}个条目中的{{start}}到{{end}}个', {count: ${data.count}, start: (page - 1) * ${pagination.size} + 1, end: Math.min(${data.count}, page * ${pagination.size})}))
                                            }
                                        });
                                    <\/script>
                                </tfoot>
                            `;
                        }
                        return {list_content, page_content};
                    })
            }

            function renderToolTip(column) {
                if (column.tooltip_diy) {
                    return column.tooltip_diy(column);
                }
                return column.tooltip ? `<span data-toggle="tooltip" data-html="true" data-original-title="${column.tooltip}" data-trigger="manual" onclick="event.preventDefault();$(this).tooltip('toggle');">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-help-circle"><circle cx="12" cy="12" r="10"></circle><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>
                </span>` : '';
            }

            function renderColumn(type, column, detail) {
                if (!column.is_edit) return '';
                if (typeof column.detail_render === 'function') return column.detail_render(column, type, columns, detail);
                let renderText = `
                    <div class="form-group">
                        <label class="form-label" for="${column.name}">${i18next.t(column.label) || column.label} ${column.valid_rule.required ? `<em>*</em>` : ''} ${renderToolTip(column)}</label>
                        <input ${type === 'view' ? 'readonly' : ''} ${column.readonly ? 'readonly' : ''} type="${column.type || 'text'}" class="form-control" id="${column.name}" name="${column.name}" placeholder="${column.placeholder || i18next.t(column.label) || column.label}" ${typeof column.default_value !== 'undefined' ? `value="${column.default_value}"` : ''}>
                    </div>
                `;
                if (column.type === 'textarea') {
                    renderText = `
                        <div class="form-group">
                            <label class="d-block" for="${column.name}">
                                ${i18next.t(column.label) || column.label} ${column.valid_rule.required ? `<em>*</em>` : ''} ${renderToolTip(column)}
                            </label>
                            <textarea ${type === 'view' ? 'readonly' : ''} ${column.readonly ? 'readonly' : ''} class="form-control" id="${column.name}" name="${column.name}" placeholder="${column.placeholder || i18next.t(column.label) || column.label}" rows="${column.rows || 5}"></textarea>
                        </div>
                    `;
                } else if (column.type === 'radio') {
                    renderText = `
                        <div class="form-group">
                            <label class="d-block">${i18next.t(column.label) || column.label} ${column.valid_rule.required ? `<em>*</em>` : ''} ${renderToolTip(column)}</label>
                            <div class="demo-inline-spacing">
                                ${column.data.map((item, index) => {
                                    return `
                                        <div class="custom-control custom-radio my-50">
                                            <input ${type === 'view' ? 'disabled' : ''} type="radio" id="${column.name}${index + 1}" name="${column.name}" value="${item}" class="custom-control-input" ${column.default_value === item ? 'checked' : ''}>
                                            <label class="custom-control-label" for="${column.name}${index + 1}">${i18next.t(item) || item}</label>
                                        </div>
                                    `
                                }).join('\n')}
                            </div>
                        </div>
                    `
                } else if (column.type === 'checkbox') {
                    renderText = `
                        <div class="form-group">
                            <label class="d-block">${i18next.t(column.label) || column.label} ${column.valid_rule.required ? `<em>*</em>` : ''} ${renderToolTip(column)}</label>
                            <div class="demo-inline-spacing">
                                ${column.data.map((item, index) => {
                                    let name;
                                    let value;
                                    if (typeof item === 'object') {
                                        name = item.name;
                                        value = item.value
                                    } else {
                                        name = item;
                                        value = item;
                                    }
                                    return `
                                        <div class="custom-control custom-checkbox mt-1 mr-1">
                                            <input ${type === 'view' ? 'disabled' : ''} type="checkbox" class="custom-control-input" id="${column.name}${index + 1}" name="${column.name}" value="${value}">
                                            <label class="custom-control-label" for="${column.name}${index + 1}">${i18next.t(name) || name}</label>
                                        </div>
                                    `
                                }).join('\n')}
                            </div>
                        </div>
                    `
                } else if (column.type === 'select') {
                    renderText = `
                        <div class="form-group">
                            <label for="${column.name}">${i18next.t(column.label) || column.label} ${column.valid_rule.required ? `<em>*</em>` : ''} ${renderToolTip(column)}</label>
                            <select ${type === 'view' ? 'disabled' : ''} class="form-control select2" ${column.is_multiple ? 'multiple' : ''} ${column.is_tag ? 'tag' : ''} id="${column.name}" name="${column.name}" >
                                <option value="">${i18next.t('请选择')}</option>
                                ${column.data.filter(item => column.dataFilter ? column.dataFilter(item, column, detail) : true).map(item => {
                                    let name;
                                    let value;
                                    if (typeof item === 'object') {
                                        name = item.name;
                                        value = item.value
                                    } else {
                                        name = item;
                                        value = item;
                                    }
                                    return `
                                        <option value="${value}" ${column.default_value === value ? 'selected' : ''}>${i18next.t(name) || name}</option>
                                    `
                                }).join('\n')}
                            </select>
                        </div>
                    `
                } else if (column.type === 'provinces') {
                    renderText = `
                        <div class="form-group">
                            <label for="${column.name}">${i18next.t(column.label) || column.label} ${column.valid_rule.required ? `<em>*</em>` : ''} ${renderToolTip(column)}</label>
                            <div style="display: flex;">
                                <select class="form-control mr-1" name="${column.name}.province"></select>
                                <select class="form-control mr-1" name="${column.name}.city"></select>
                                <select class="form-control" name="${column.name}.area"></select>
                            </div>
                            <script>
                                new PCAS("${column.name}.province", "${column.name}.city", "${column.name}.area", "", "", "");
                            </script>
                        </div>
                    `
                } else if (column.type === 'datetime-local') {
                    renderText = `
                        <div class="form-group">
                            <label class="form-label" for="${column.name}">${i18next.t(column.label) || column.label} ${column.valid_rule.required ? `<em>*</em>` : ''} ${renderToolTip(column)}</label>
                            <input ${type === 'view' ? 'readonly' : ''} type="datetime-local" class="form-control" id="${column.name}" name="${column.name}" placeholder="${column.placeholder || column.label}">
                        </div>
                    `
                } else if (column.type === 'date-range') {
                    renderText = `
                        <div class="form-group">
                            <label class="form-label" for="${column.name}">${i18next.t(column.label) || column.label} ${column.valid_rule.required ? `<em>*</em>` : ''} ${renderToolTip(column)}</label>
                            <input ${type === 'view' ? 'readonly' : ''} class="form-control flatpickr-range" id="${column.name}" name="${column.name}" placeholder="${column.placeholder || column.label}">
                        </div>
                    `
                } else if (column.type === 'file') {
                    renderText = `
                        <div class="form-group">
                            <label class="form-label" for="${column.name}">${i18next.t(column.label) || column.label} ${column.valid_rule.required ? `<em>*</em>` : ''} ${renderToolTip(column)}</label>
                            <div ${type === 'view' ? 'disabled' : ''} class="dropzone dropzone-area multiple-files" id="${column.name}" maxFiles="${column.maxFiles || 5}" maxFilesize="${column.maxFilesize || 10}">
                                <div class="dz-message">${i18next.t('将文件拖放到此处或单击上传')}。</div>
                            </div>
                            <input name="${column.name}" type="hidden" />
                        </div>
                    `
                } else if (column.type === 'single_file') {
                    renderText = `
                        <div class="form-group">
                            <label class="form-label" for="${column.name}">${i18next.t(column.label) || column.label} ${column.valid_rule.required ? `<em>*</em>` : ''} ${renderToolTip(column)}</label>
                            <div class="media flex-column flex-md-row border rounded p-1">
                                <a href="#" target="_blank" class="img" style="position: relative;">
                                    <img src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" class="rounded mr-2 mb-1 mb-md-0" style="width: 100px;height: 70px; object-fit: cover" onerror="this.src='/jiaogeiwo/images/file.png'">
                                    <button class="btn btn-icon btn-icon rounded-circle btn-flat-primary waves-effect custom-img-upload-del" style="position: absolute;top: 0;right: 0;" type="button">×</button>
                                </a>
                                <div class="media-body">
                                    <small class="text-muted mb-50">${column.placeholder || 'Required file resolution.'}</small>
                                    <div class="d-inline-block mt-50">
                                        <div class="form-group mb-0">
                                            <div class="custom-file">
                                                <input type="file" class="custom-file-input custom-img-upload" id="${column.name}" name="${column.name}" accept="*/*" aria-invalid="false">
                                                <label class="custom-file-label" for="${column.name}" data-browse="${i18next.t('浏览')}">${i18next.t('选择文件')}</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `
                } else if (column.type === 'image') {
                    renderText = `
                        <div class="form-group">
                            <label class="form-label" for="${column.name}">${i18next.t(column.label) || column.label} ${column.valid_rule.required ? `<em>*</em>` : ''} ${renderToolTip(column)}</label>
                            <div class="media flex-column flex-md-row border rounded p-1">
                                <a href="#" target="_blank" class="img" style="position: relative;">
                                    <img src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" class="rounded mr-2 mb-1 mb-md-0" style="width: 100px;height: 70px; object-fit: cover">
                                    <button class="btn btn-icon btn-icon rounded-circle btn-flat-primary waves-effect custom-img-upload-del" style="position: absolute;top: 0;right: 0;" type="button">×</button>
                                </a>
                                <div class="media-body">
                                    <small class="text-muted mb-50">${column.placeholder || 'Required image resolution.'}</small>
                                    <div class="d-inline-block mt-50">
                                        <div class="form-group mb-0">
                                            <div class="custom-file">
                                                <input type="file" class="custom-file-input custom-img-upload" id="${column.name}" name="${column.name}" accept="image/*" aria-invalid="false">
                                                <label class="custom-file-label" for="${column.name}" data-browse="${i18next.t('浏览')}">${i18next.t('选择文件')}</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `
                } else if (column.type === 'images') {
                    renderText = `
                        <div class="form-group">
                            <label class="form-label" for="${column.name}">${i18next.t(column.label) || column.label} ${column.valid_rule.required ? `<em>*</em>` : ''} ${renderToolTip(column)}</label>
                            <div ${type === 'view' ? 'disabled' : ''} class="dropzone dropzone-area multiple-images" id="${column.name}" acceptedFiles="image/*" maxFiles="${column.maxFiles || 5}" maxFilesize="${column.maxFilesize || 10}">
                                <div class="dz-message">${i18next.t('将图片拖放到此处或单击上传')}。</div>
                            </div>
                            <input name="${column.name}" type="hidden" />
                        </div>
                    `
                } else if (column.type === 'repeater') {
                    renderText = `
                    <label class="form-label">${i18next.t(column.label)} ${column.valid_rule.required ? `<em>*</em>` : ''} ${renderToolTip(column)}</label>
                    <div class="card">
                        <div class="card-body">
                            <div class="${column.name}-repeater">
                                <div data-repeater-list="${column.name}">
                                    <div data-repeater-item>
                                        <div class="row d-flex align-items-end justify-content-between">
                                            ${(column.children || []).map(childColumn => {
                                                const md_cls = childColumn.detail_class || `col-md-${Math.floor((12 - 1) / column.children.length)}`;
                                                return `<div class="${md_cls} col-12" style="padding-left: 4px; padding-right: 4px;">
                                                    ${renderColumn(type, {...default_column, ...childColumn, detail_class: '', name: `${column.name}_${childColumn.name}`})}
                                                </div>`;
                                            }).join('\n')}
                                            <div class="col-md-1 col-12" style="padding-left: 4px; padding-right: 4px;">
                                                <div class="form-group">
                                                    <button class="btn btn-outline-danger text-nowrap px-1" data-repeater-delete type="button">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x mr-25"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                                                        <span>${i18next.t('删除')}</span>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                        <hr />
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <button class="btn btn-icon btn-primary" type="button" data-repeater-create>
                                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus mr-25"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                                            <span>${i18next.t('新增')}</span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        ${type === 'add' ? `<script>
                            var ${column.name}_repeater = $('.${column.name}-repeater').repeater({
                                defaultValues: ${JSON.stringify((column.children || []).filter(item => typeof item.default_value !== 'undefined').reduce((prev, curr) => {
                                    return {...prev, [column.name + '_' + curr.name]: curr.default_value}
                                }, {}))},
                                show: function () {
                                    $(this).slideDown();
                                },
                                hide: function (deleteElement) {
                                    if (confirm(i18next.t('您确定要删除这行数据吗?'))) {
                                        $(this).slideUp(deleteElement);
                                    }
                                }
                            });
                        <\/script>` : ''}
                    </div>`;
                } else if (column.type === "richtext") {
                    renderText = `
                    <div class="form-group">
                        <label class="form-label" for="${column.name}">${i18next.t(column.label) || column.label} ${column.valid_rule.required ? `<em>*</em>` : ''} ${renderToolTip(column)}</label>
                        <textarea ${type === 'view' ? 'disabled' : ''} id="${column.name}" name="${column.name}"></textarea>
                    </div>
                    
                    <script>
                        window['${column.name}EditorPromise'] = ClassicEditor
                                .create( document.querySelector( '#${column.name}' ), {
                                    ${i18next.language !== 'zh-CN' ? `language: '${i18next.language}',` : ''}
                                    licenseKey: '',
                                    simpleUpload: {
                                        // The URL that the images are uploaded to.
                                        uploadUrl: '//yun-api.sungdell.com/upload-file?siteName=${jiaogeiwo.vars.project}',
                                    }
                                })
                                .then(edit => {
                                    window['${column.name}Editor'] = edit;
                                    return edit;
                                })
                                .catch( error => {
                                    console.error( error );
                                } );
                    <\/script>
                    `
                }
                
                return `
                    <div class="${column.detail_class}">
                        ${renderText}
                    </div>
                `;
            }

            function renderColumns(type, detail) {
                return columns.map(column => {
                    return renderColumn(type, column, detail);
                }).join('\n');
            }

            function getFormDataByColumns(columns, selector) {
                let formData = {};
                columns.forEach(column => {
                    let value = $(selector + ` input[name="${column.name}"]`).val();
                    if (typeof value === 'string') {
                        value = value.trim();
                    }
                    if (typeof column.get_val === 'function') {
                        value = column.get_val(form, column, columns);
                    } else {
                        if (column.type === 'number') {
                            value = +value;
                        } else if (column.type === 'textarea') {
                            value = $(selector + ` textarea[name="${column.name}"]`).val();
                        } else if (column.type === 'radio') {
                            value = $(selector + ` input[name="${column.name}"]:checked`).val();
                        } else if (column.type === 'checkbox') {
                            value = $(selector + ` input[name="${column.name}"]:checked`).map((index, elem) => $(elem).val());
                        } else if (column.type === 'select') {
                            value = $(selector + ` select[name=${column.name}]`).val();
                            if (value && column.text_name) { // select类型,冗余名称
                                formData[column.text_name] = $(selector + ` select[name=${column.name}] option[value=${$(selector + ` select[name=${column.name}]`).val()}]`).text()
                            }
                        } else if (column.type === 'provinces') {
                            value = {
                                province: $(selector + ` select[name="${column.name}.province"]`).val(),
                                city: $(selector + ` select[name="${column.name}.city"]`).val(),
                                area: $(selector + ` select[name="${column.name}.area"]`).val(),
                            }
                        } else if (column.type === 'datetime-local') {
                            value = $(selector + ` input[name="${column.name}"]`).val();
                        } else if (column.type === 'date-range') {
                            value = {
                                start_date: $(selector + ` input[name="${column.name}"]`).attr('start_date'),
                                end_date: $(selector + ` input[name="${column.name}"]`).attr('end_date'),
                                text: $(selector + ` input[name="${column.name}"]`).val()
                            };
                        } else if (column.type === 'file') {
                            const files = $(selector + ` input[name="${column.name}"]`).attr('value')
                            value = files ? files.split(',') : [];
                        } else if (column.type === 'single_file') {
                            value = $(selector + ` input[name="${column.name}"]`).attr('value');
                        }  else if (column.type === 'image') {
                            value = $(selector + ` input[name="${column.name}"]`).attr('value');
                        } else if (column.type === 'images') {
                            const images = $(selector + ` input[name="${column.name}"]`).attr('value')
                            value = images ? images.split(',') : [];
                        } else if (column.type === 'repeater') {
                            value = $(selector + ` .${column.name}-repeater`).repeaterVal()[column.name];
                        } else if (column.type === 'richtext') {
                            value = window[`${column.name}Editor`].getData();
                            // 计算字数
                            formData[column.name + "_count"] = $(value).text().length;
                        }
                    }
                    
                    formData[column.name] = value;
                });
                return formData;
            }

            function initDetailValidate(selector, type) {
                console.info({
                    ...columns.reduce((prev, curr) => {
                        return {...prev, [curr.name]: curr.valid_rule}
                    }, {})
                })
                // 校验
                $(selector + ' form').validate({
                    ignore: "",
                    rules: {
                        ...columns.reduce((prev, curr) => {
                            return {...prev, [curr.name]: curr.valid_rule}
                        }, {})
                    },
                    submitHandler: (form, event) => {
                        console.info(form);
                        console.info('调用数据接口');
                        try {
                            const formData = {
                                _id: $(selector + ` input[name=_id]`).val(),
                                ...getFormDataByColumns(columns.filter(column => !!column.is_edit), selector),
                            };
                            
                            console.info(formData);
                            jiaogeiwo.http.post(type === 'add' ? api.add : api.update, formData)
                                .then((data) => {
                                    // custom event
                                    if (typeof customEvent[`${type}-event`] === 'function') {
                                        customEvent[`${type}-event`](data);
                                    }

                                    $(`#${name}-modals-detail`).modal('hide');
                                    updateList();
                                })
                        } catch (error) {
                            console.info(error);
                        }
                    }
                });
            }

            function initDetailEvent(selector, type) {
                // select2
                $(selector + ' .select2').filter(function() {
                    return $(this).closest('[data-repeater-list]').length === 0;
                }).each(function () {
                    var $this = $(this);
                    $this.wrap('<div class="position-relative"></div>');
                    $this
                    .select2({
                        placeholder: i18next.t('请选择'),
                        dropdownParent: $this.parent(),
                        tags: $this.attr('tag') !== undefined,
                        // createTag: function (params) {
                        //     var term = $.trim(params.term);
                    
                        //     if (term === '') {
                        //         return null;
                        //     }

                        //     if (/[，,]/.test(params.term)) {//支持【逗号】结尾生成tags
                        //         var str = params.term.trim().replace(/[,;，；]*$/, '');
                        //         return { id: str, text: str, newOption: true}
                        //     } else {
                        //         return null;
                        //     }
                        // },
                        allowClear: true,
                    })
                    .change(function () {
                        $(this).valid();
                    });
                });

                // flatpickr
                $(selector + ' .flatpickr-range').flatpickr({
                    mode: 'range',
                    locale: i18next.language,
                    onChange: function(selectedDates, dateStr, instance) {
                        console.info(selectedDates)
                        selectedDates[0] && $(selector + ' .flatpickr-range').attr('start_date', flatpickr.formatDate(selectedDates[0], "Y-m-d"));
                        selectedDates[1] && $(selector + ' .flatpickr-range').attr('end_date', flatpickr.formatDate(selectedDates[1], "Y-m-d"));
                    }
                });

                // 单图片、单文件上传
                $(selector).on('change', '.custom-img-upload', function (e) {
                    const files = e.target.files;
                    const fd = new FormData();
                    fd.append('file', files[0]);
                    fetch(`//yun-api.sungdell.com/upload-file?siteName=${jiaogeiwo.vars.project}`, {
                        mode: 'cors',
                        method: 'POST',
                        body: fd,
                    }).then(res => {
                        return res.json();
                    }).then(res => {
                        console.log('res is',res);
                        $(e.target).attr('value', res.url);
                        $(e.target).closest('.media')
                            .find('.img').attr('href', res.url)
                            .find('img').attr('src', res.url);
                        $(e.target).closest('.media')
                            .find('.custom-file-label').text(res.url.substring(res.url.lastIndexOf('/') + 1));
                    });
                });
                $(selector).on('click', '.custom-img-upload-del', function(e) {
                    e.preventDefault();
                    $(e.target).closest('.media').find('.custom-img-upload').attr('value', 'data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=');
                    $(e.target).closest('.media')
                            .find('.img').attr('href', 'data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=')
                            .find('img').attr('src', 'data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=');
                    $(e.target).closest('.media')
                            .find('.custom-file-label').text(i18next.t('选择文件'));
                })

                // dropzone file
                $(selector + ' .dropzone').each((index, elem) => {
                    $(elem).dropzone({
                        url: `//yun-api.sungdell.com/upload-file?siteName=${jiaogeiwo.vars.project}`,
                        headers: {'X-Requested-With': ''},
                        paramName: 'file', // The name that will be used to transfer the file
                        maxFilesize: +$(elem).attr('maxFilesize'), // MB
                        maxFiles: +$(elem).attr('maxFiles'),
                        clickable: true,
                        addRemoveLinks: true,
                        dictRemoveFile: i18next.t('删除'),
                        acceptedFiles: $(elem).attr('acceptedFiles'),
                        transformFile: function (file, done) { // 兼容heic图片：//cdn.xuansiwei.com/common/lib/heic2any/heic2any.min.js
                            console.info(file.type);
                            if (file.type === 'image/heic') {
                                heic2any({ blob: file, toType: "image/jpeg" })
                                    .then(fileBlob => {
                                        const newFile = new File([fileBlob], file.name + ".jpg", { type: "image/jpeg" });
                            
                                        // transfer current file details
                                        newFile.accepted = file.accepted;
                                        newFile.processing = file.processing;
                                        newFile.status = file.status;
                                        newFile.upload = file.upload;
                            
                                        // Change the upload file name to reflect the converted details
                                        newFile.upload.filename = newFile.name;
                            
                                        done(newFile);
                                });
                            } else if (file.type.indexOf('image') !== -1) {
                                // 压缩图片
                                var reader = new FileReader(), img = new Image();
                                // 读文件成功的回调
                                reader.onload = function(e) {
                                    // e.target.result就是图片的base64地址信息
                                    img.src = e.target.result;
                                };
                                img.onload = function(e) {
                                    if (this.width > 1920 || this.height > 1080) { // 压缩
                                        let width = this.width;
                                        let height = this.height;
                                        if (width > 1920) {
                                            width = 1920;
                                            height = 1920 * (this.height / this.width);
                                        }
                                        if (height > 1080) {
                                            height = 1080;
                                            width = 1080 * (this.width / this.height)
                                        }
                                        console.info('压缩图片大小');
                                        var canvas = document.createElement('canvas');
                                        var context = canvas.getContext('2d');
                                        canvas.width = width;
                                        canvas.height = height;
                                        // 核心JS就这个
                                        context.drawImage(this, 0, 0, width, height);
                                        canvas.toBlob((blob) => {
                                            blob.lastModifiedDate = new Date();
                                            blob.name = file.name;
                                            console.info(`压缩前图片大小: ${file.size}, ${this.width} * ${this.height}, 压缩后图片大小: ${blob.size}, ${width} * ${height}`);
                                            done(blob);
                                        }, file.type)
                                    } else {
                                        done(file);
                                    }
                                }
                                reader.readAsDataURL(file);
                            } else {
                                done(file);
                            }
                        },
                        init: function() {
                            this.on("success", function(event, res) {
                                console.info(res);
                                var value = $(selector + ' input[name=' + $(elem).attr('id') + ']').val();
                                var values = value ? value.split(',') : [];
                                values.push(res.url);
                                $(selector + ' input[name=' + $(elem).attr('id') + ']').val(values.join(','));
                                $(selector + ' input[name=' + $(elem).attr('id') + ']').valid();
                            });
                            this.on("removedfile", function(file) {
                                console.info(file);
                                var value = $(selector + ' input[name=' + $(elem).attr('id') + ']').val();
                                value = value.split(',').filter(item => item.substring(item.lastIndexOf('/') + 1) !== file.name).join(',');
                                $(selector + ' input[name=' + $(elem).attr('id') + ']').val(value);
                                $(selector + ' input[name=' + $(elem).attr('id') + ']').valid();
                            });
                            this.on("addedfile", function(file) { 
                                if ( this.files.length > $(elem).attr('maxFiles')) {
                                    this.removeFile(this.files[0]); 
                                }
                            })
                        }
                    });
                })
            }
            function renderFilter() {
                const filterColumns = columns.filter(column => column.is_filter);
                return `
                    ${filterColumns.length > 0 ? `<div class="card">
                        <div class="card-header row" id="radio_field_query" style="justify-content: unset;">
                            ${filterColumns.map(column => {
                                const counts = column.counts || [];
                                const countSum = counts.map(item => item.count).reduce((prev, curr) => prev + curr, 0);
                                if (column.filter_type === 'select') {
                                    return `<div class="col-sm-12 col-md-6">
                                        <div class="demo-inline-spacing">
                                            <label class="my-50" for="${column.name}">${i18next.t(column.label)}: </label>
                                            <div class="my-50" style="flex: 1 1 0%;">
                                                <select class="form-control select2" ${column.is_multiple ? 'multiple' : ''} ${column.is_tag ? 'tag' : ''} id="${column.name}" name="${column.name}" >
                                                    <option value="">${i18next.t('请选择')}</option>
                                                    ${column.data.map((item, index) => {
                                                        if (typeof item === 'string') {
                                                            item = {name: item ,value: item};
                                                        }
                                                        const countObj = counts.find(it => it._id === item.value);
                                                        return `<option value="${item.value}">${i18next.t(item.name)}${countObj ? `(${countObj.count})` : ''}</option>`;
                                                    }).join('\n')}
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <script>
                                        $('#radio_field_query .select2').each(function () {
                                            var $this = $(this);
                                            $this.wrap('<div class="position-relative"></div>');
                                            $this
                                            .select2({
                                                placeholder: i18next.t('请选择'),
                                                dropdownParent: $this.parent(),
                                                tags: $this.attr('tag') !== undefined,
                                                allowClear: true
                                            });
                                        });
                                    </script>
                                    `
                                }
                                if (column.filter_type === 'date') {
                                    return `<div class="col-sm-12 col-md-6">
                                        <div class="demo-inline-spacing">
                                            <label class="my-50" for="${column.name}">${i18next.t(column.label)}: </label>
                                            <div class="my-50" style="flex: 1 1 0%;">
                                                <input class="form-control flatpickr-range" id="${column.name}" name="${column.name}" placeholder="${i18next.t(column.placeholder || column.label)}">
                                            </div>
                                        </div>
                                    </div>
                                    <script>
                                        $('#radio_field_query .flatpickr-range').flatpickr({
                                            mode: 'range',
                                            locale: i18next.language,
                                            onChange: function(selectedDates, dateStr, instance) {
                                                console.info(selectedDates, dateStr, instance);
                                                selectedDates[0] && $(instance.element).attr('start_date', flatpickr.formatDate(selectedDates[0], "Y-m-d"));
                                                selectedDates[1] && $(instance.element).attr('end_date', flatpickr.formatDate(selectedDates[1], "Y-m-d"));
                                            }
                                        });
                                    </script>
                                    `
                                }
                                return `
                                    <div class="col-sm-12 col-md-6">
                                        <div class="demo-inline-spacing">
                                            <label class="my-50">${i18next.t(column.label)}: </label>
                                            
                                            <div class="custom-control custom-radio my-50">
                                                <input type="radio" id="filter_${column.name}0" name="${column.name}" value="" class="custom-control-input" checked>
                                                <label class="custom-control-label" for="filter_${column.name}0">${i18next.t('全部')}${countSum ? `(${countSum})` : ''}</label>
                                            </div>
                                            ${column.data.map((item, index) => {
                                                if (typeof item === 'string') {
                                                    item = {name: item ,value: item};
                                                }
                                                const countObj = counts.find(it => it._id === item.value);
                                                return `<div class="custom-control custom-radio my-50">
                                                    <input type="radio" id="filter_${column.name}${index + 1}" name="${column.name}" value="${item.value}" class="custom-control-input">
                                                    <label class="custom-control-label" for="filter_${column.name}${index + 1}">${i18next.t(item.name)}${countObj ? `(${countObj.count})` : ''}</label>
                                                </div>`
                                            }).join('\n')}
                                        </div>
                                    </div>
                                `
                            }).join('\n')}
                        </div>
                    </div>` : ''}
                `
            }
            function getDetail(type, title, content) {
                return `
                    <form class="add-new-record modal-content pt-0" type="${type}" onsubmit="return false;">
                        <input type="text" style="display: none;" name="_id">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">×</button>
                        <div class="modal-header mb-1">
                            <h5 class="modal-title" id="exampleModalLabel">${title}</h5>
                        </div>
                        <div class="modal-body flex-grow-1">
                            <div class="row">
                                ${content}    
                            </div>
                            ${footer_html ? footer_html : '' }
                            ${type === 'view' ? `` : `<div class="mt-4">
                                <button type="submit" class="btn btn-primary data-submit mr-1 waves-effect waves-float waves-light">${i18next.t('保存')}</button>
                                <button type="reset" class="btn btn-outline-secondary waves-effect" data-dismiss="modal">${i18next.t('取消')}</button>
                            </div>`}
                        </div>
                    </form>
                `
            }
            
            return getList()
                .then(({list_content, page_content}) => {
                    $(`#${name}`).html(`
                        ${is_filter ? renderFilter() : ''}
                        <div class="card">
                            <div class="card-header row">
                                <div class="col-sm-12 col-md-4">
                                    ${is_search ? `<div class="input-group" id="fuzzy-query">
                                        <input type="text" class="form-control" placeholder="${i18next.t('模糊搜索')}" />
                                        <div class="input-group-append">
                                            <button class="btn btn-outline-primary" type="button">${i18next.t('查询')} !</button>
                                        </div>
                                    </div>` : ``}
                                </div>
                                <div class="col-sm-12 col-md-2">
                                    ${is_multi ? `<div class="check_all_div hidden">
                                        <button class="dt-button buttons-collection btn btn-outline-secondary dropdown-toggle" data-toggle="dropdown" tabindex="0" type="button" aria-haspopup="true">
                                            <span>${i18next.t('批量选中')} <span class="check_all_num"></span> ${i18next.t('条')}${i18next.t('数据')}</span>
                                        </button>
                                        <div class="dropdown-menu" style="">
                                            <a class="dropdown-item delete" href="javascript:void(0);">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash mr-1"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg><span class="align-middle">${i18next.t('删除选中')} <span class="check_all_num"></span> ${i18next.t('条')}${i18next.t('数据')}</span>
                                            </a>
                                            <a class="dropdown-item delete-all hidden" href="javascript:void(0);">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash mr-1"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg><span class="align-middle">${i18next.t('删除全部')} <span class="check_query_all_num"></span> ${i18next.t('条')}${i18next.t('数据')}</span>
                                            </a>
                                            ${columns.filter(item => !!item.is_alone_edit).map(item => {
                                                return ` <a class="dropdown-item update" column_name="${item.name}" href="javascript:void(0);">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit font-small-4"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg><span class="align-middle ml-1">${i18next.t('批量修改')}${item.label}</span>
                                                </a>`
                                            }).join('\n')}
                                            ${multi_more.map(item => {
                                                return item.html;
                                            }).join('\n')}
                                        </div>
                                    </div>` : ''}
                                </div>
                                <div class="col-sm-12 col-md-6 text-right">
                                    ${is_add ? `<div class="dt-action-buttons">
                                        <div class="dt-buttons d-inline-flex"> 
                                            <button class="dt-button create-new btn btn-primary mr-2" tabindex="0"type="button">
                                                <span><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus mr-50 font-small-4"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>${i18next.t('新增')}</span>
                                            </button>
                                            ${is_add_upload ? `<div>
                                                <button class="dt-button buttons-collection btn btn-outline-secondary dropdown-toggle" data-toggle="dropdown" tabindex="0" type="button" aria-haspopup="true">
                                                    <span><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-upload mr-50 font-small-4"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="17 8 12 3 7 8"></polyline><line x1="12" y1="3" x2="12" y2="15"></line></svg>${i18next.t('批量导入导出')}</span>
                                                </button>
                                                <div class="dropdown-menu" style="">
                                                    <a class="dropdown-item download-tpl" href="javascript:void(0);">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-download-cloud mr-1"><polyline points="8 17 12 21 16 17"></polyline><line x1="12" y1="12" x2="12" y2="21"></line><path d="M20.88 18.09A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.29"></path></svg><span class="align-middle">${i18next.t('下载模版')}(EXCEL)</span>
                                                    </a>
                                                    <a class="dropdown-item" href="javascript:$('#upload-excel-input').click();">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-upload-cloud mr-1"><polyline points="16 16 12 12 8 16"></polyline><line x1="12" y1="12" x2="12" y2="21"></line><path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3"></path><polyline points="16 16 12 12 8 16"></polyline></svg><span class="align-middle">${i18next.t('导入数据')}(EXCEL)</span>
                                                        <input id="upload-excel-input" type="file" style="display: none;" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet">
                                                    </a>
                                                    <a class="dropdown-item download-excel">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-download-cloud mr-1"><polyline points="8 17 12 21 16 17"></polyline><line x1="12" y1="12" x2="12" y2="21"></line><path d="M20.88 18.09A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.29"></path></svg><span class="align-middle">${i18next.t('导出数据')}(EXCEL)</span>
                                                    </a>
                                                    <a class="dropdown-item upload-dir" href="javascript:;">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-upload-cloud mr-1"><polyline points="16 16 12 12 8 16"></polyline><line x1="12" y1="12" x2="12" y2="21"></line><path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3"></path><polyline points="16 16 12 12 8 16"></polyline></svg><span class="align-middle">${i18next.t('导入文件夹')}</span>
                                                    </a>
                                                </div>
                                            </div>` : ''}
                                        </div>
                                    </div>` : ''}
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            ${is_multi ? `<th>
                                                <div class="custom-control custom-checkbox"> 
                                                    <input class="custom-control-input page-checkbox" type="checkbox" value="" id="checkboxSelectAll">
                                                    <label class="custom-control-label" for="checkboxSelectAll"></label>
                                                </div>
                                            </th>` : ''}
                                            ${columns.filter(column => column.is_show).map((column) => {
                                                return `<th>${i18next.t(column.label) || column.label}</th>`;
                                            }).join('\n')}
                                            ${is_operation ? `<th>${i18next.t('操作')}</th>` : ''}
                                        </tr>
                                    </thead>
                                    ${list_content}
                                    ${page_content}
                                </table>
                            </div>
                        </div>
                        <div class="modal modal-slide-in fade" id="${name}-modals-detail">
                            <div class="modal-dialog sidebar-lg" style="width: ${detail_width};"></div>
                        </div>
                        <div class="modal fade" id="${name}-alone-edit-modal" tabindex="-1" role="dialog">
                            <div class="modal-dialog modal-dialog-centered" role="document">
                                <div class="modal-content">
                                </div>
                            </div>
                        </div>
                        <div class="modal fade" id="${name}-tooltip" tabindex="-1" role="dialog">
                            <div class="modal-dialog modal-dialog-centered" role="document">
                                <div class="modal-content">
                                </div>
                            </div>
                        </div>
                        <div class="modal fade" id="${name}-upload-dir-modal" tabindex="-1" role="dialog">
                            <div class="modal-dialog modal-dialog-centered" role="document">
                                <div class="modal-content">
                                </div>
                            </div>
                        </div>
                    `);

                     // 初始化事件
                    // 查询
                    function searchFn() {
                        const andObj = {};
                        $(`#${name} #radio_field_query input:checked`).each((index, elem) => {
                            andObj[$(elem).attr('name')] = $(elem).val();
                        });

                        $(`#${name} #radio_field_query select`).each((index, elem) => {
                            if ($(elem).val()) {
                                andObj[$(elem).attr('name')] = $(elem).val();
                            }
                        });

                        $(`#${name} #radio_field_query .flatpickr-range`).each((index, elem) => {
                            if ($(elem).attr('start_date') || $(elem).attr('end_date')) {
                                andObj[$(elem).attr('name')] = {type: 'date', $gte: $(elem).attr('start_date'), $lt: $(elem).attr('end_date')};
                            }
                        });

                        params = {
                            ...params,
                            or: columns.filter(item => item.is_search).reduce((prev, curr) => {
                                if (curr.filter_names) {
                                    curr.filter_names.forEach(key => prev[key] = ($(`#${name} #fuzzy-query input`).val() || '').trim());
                                    return {...prev};
                                }
                                if (curr.data && curr.data[0] && curr.data[0].value) {
                                    const valueData = curr.data.find(item => item.name === ($(`#${name} #fuzzy-query input`).val() || '').trim()) || {};
                                    return {...prev, [curr.name]: valueData.value}
                                }
                                return {...prev, [curr.name]: ($(`#${name} #fuzzy-query input`).val() || '').trim()}
                            }, {}),
                            and: andObj
                        }
                        // 查询时重置页数
                        pagination.index = page_index;
                        updateList();
                    }
                    $(`#${name} #radio_field_query`).on('change', 'input', function (event) {
                        searchFn();
                    });
                    $(`#${name} #fuzzy-query button`).on("click", function (event) {
                        event.preventDefault();
                        searchFn();
                    });
                    $(`#${name} #fuzzy-query input`).on('keypress', function (event) {
                        if (event.keyCode == 13)  { 
                            $('#fuzzy-query button').trigger('click');
                        }
                    });
                    $(`#${name} #radio_field_query`).on('change', 'select', function (event) {
                        searchFn({[`${event.target.id}`]: $(event.target).val()});
                    });

                    // 新增按钮
                    $(`#${name} .create-new`).on('click', () => {
                        const content = renderColumns('add');
                        const detailHtml = getDetail('add', `${i18next.t('新增')} ${i18next.t(moduleName) || moduleName}` , content);
                        const selector = `#${name}-modals-detail .modal-dialog`;
                        $(selector).html(detailHtml);
                        initDetailEvent(selector, 'add');
                        initDetailValidate(selector, 'add');
                        $(`#${name}-modals-detail`).modal('show');
                    });

                    // 删除按钮
                    $(`#${name}`).on("click", '.item-del', function (event) {
                        event.preventDefault();
                        Swal.fire({
                            title: `${i18next.t('您确定吗')}?`,
                            text: del_intro(event),
                            icon: 'warning',
                            showCancelButton: true,
                            confirmButtonText: `${i18next.t('是的')}, ${i18next.t('删除它')}!`,
                            cancelButtonText: `${i18next.t('取消')}!`,
                            customClass: {
                            confirmButton: 'btn btn-primary',
                            cancelButton: 'btn btn-outline-danger ml-1'
                            },
                            buttonsStyling: false
                        }).then( (result) => {
                            if (result.value) {
                                jiaogeiwo.http.get(`${api.delete}?id=${$(this).attr('uid')}`)
                                    .then((data) => {
                                        // custom event
                                        if (typeof customEvent['delete-event'] === 'function') {
                                            customEvent['delete-event'](data);
                                        }

                                        Swal.fire({
                                            icon: 'success',
                                            title: `${i18next.t('删除了')}!`,
                                            text: `${i18next.t('这条数据已经删除成功')}.`,
                                            customClass: {
                                            confirmButton: 'btn btn-success'
                                            }
                                        });
                                        updateList();
                                    })
                            }
                        });
                    });

                    // 多选删除
                    $(`#${name}`).on("change", '.item-checkbox', function (event) {
                        event.preventDefault();
                        console.info(event.target.checked);
                        deletes[$(this).attr('uid')] = event.target.checked;
                        const count = Object.keys(deletes).filter(item => !!deletes[item]).length;
                        if (count > 0) {
                            $(`#${name} .check_all_div`).removeClass('hidden');
                            $(`#${name} .check_all_div .check_all_num`).text(count);
                            $(`#${name} .check_all_div .check_query_all_num`).text(pagination.all_count);
                            
                        } else {
                            $(`#${name} .check_all_div`).addClass('hidden');
                            $(`#${name} .check_all_div .check_all_num`).text(0);
                            $(`#${name} .check_all_div .check_query_all_num`).text(0);
                        }
                    });

                    // 页面全选
                    $(`#${name}`).on("change", '.page-checkbox', function (event) {
                        event.preventDefault();
                        $(`#${name} .item-checkbox`).each((index, elem) => {
                            $(elem).prop('checked', event.target.checked);
                            deletes[$(elem).attr('uid')] = event.target.checked;
                        });
                        const count = Object.keys(deletes).filter(item => !!deletes[item]).length;
                        if (count > 0) {
                            $(`#${name} .check_all_div`).removeClass('hidden');
                            $(`#${name} .check_all_div .delete-all`).removeClass('hidden');
                            $(`#${name} .check_all_div .check_all_num`).text(count);
                            $(`#${name} .check_all_div .check_query_all_num`).text(pagination.all_count);
                        } else {
                            $(`#${name} .check_all_div`).addClass('hidden');
                            $(`#${name} .check_all_div .delete-all`).addClass('hidden');
                            $(`#${name} .check_all_div .check_all_num`).text(0);
                            $(`#${name} .check_all_div .check_query_all_num`).text(0);
                        }
                    });

                    // 批量删除
                    $(`#${name} .check_all_div .delete`).on('click', function(event) {
                        event.preventDefault();
                        const items = Object.keys(deletes).filter(item => !!deletes[item]);
                        Swal.fire({
                            title: `你确定删除选中的${items.length}数据吗?`,
                            text: "您将无法还原此内容！",
                            icon: 'warning',
                            showCancelButton: true,
                            confirmButtonText: '是的，删除它们!',
                            cancelButtonText: '取消!',
                            customClass: {
                            confirmButton: 'btn btn-primary',
                            cancelButton: 'btn btn-outline-danger ml-1'
                            },
                            buttonsStyling: false
                        }).then( (result) => {
                            if (result.value) {
                                jiaogeiwo.http.get(`${api.deletes}?ids=` + items.join(','))
                                    .then((data) => {
                                        // custom event
                                        if (typeof customEvent['deletes-event'] === 'function') {
                                            customEvent['deletes-event'](data);
                                        }

                                        Swal.fire({
                                            icon: 'success',
                                            title: '删除了!',
                                            text: `这${items.length}条数据已经删除成功.`,
                                            customClass: {
                                            confirmButton: 'btn btn-success'
                                            }
                                        });
                                        deletes = {};
                                        $(`#${name} .page-checkbox`).prop('checked', false);
                                        $(`#${name} .check_all_div`).addClass('hidden');
                                        $(`#${name} .check_all_div .check_all_num`).text(0);
                                        $(`#${name} .check_all_div .check_query_all_num`).text(0);
                                        updateList();
                                    })
                            }
                        });
                    });

                    // 批量删除全部
                    $(`#${name} .check_all_div .delete-all`).on('click', function(event) {
                        event.preventDefault();
                        Swal.fire({
                            title: `你确定删除选中的${pagination.all_count}数据吗?`,
                            text: "您将无法还原此内容！",
                            icon: 'warning',
                            showCancelButton: true,
                            confirmButtonText: '是的，删除它们!',
                            cancelButtonText: '取消!',
                            customClass: {
                            confirmButton: 'btn btn-primary',
                            cancelButton: 'btn btn-outline-danger ml-1'
                            },
                            buttonsStyling: false
                        }).then( (result) => {
                            if (result.value) {
                                jiaogeiwo.http.post(api.deleteAll, params)
                                    .then((data) => {
                                        // custom event
                                        if (typeof customEvent['deleteAll-event'] === 'function') {
                                            customEvent['deleteAll-event'](data);
                                        }

                                        Swal.fire({
                                            icon: 'success',
                                            title: '删除了!',
                                            text: `这${pagination.all_count}条数据已经删除成功.`,
                                            customClass: {
                                            confirmButton: 'btn btn-success'
                                            }
                                        });
                                        deletes = {};
                                        $(`#${name} .page-checkbox`).prop('checked', false);
                                        $(`#${name} .check_all_div`).addClass('hidden');
                                        $(`#${name} .check_all_div .check_all_num`).text(0);
                                        $(`#${name} .check_all_div .check_query_all_num`).text(0);
                                        updateList();
                                    })
                            }
                        });
                    });

                    // 批量修改
                    $(`#${name} .check_all_div .update`).on('click', function(event) {
                        event.preventDefault();
                        const items = Object.keys(deletes).filter(item => !!deletes[item]);
                        console.info(items);
                        const column = columns.find(item => item.name === $(this).attr('column_name'));
                        const selector = `#${name}-alone-edit-modal .modal-content`;
                        $(selector).html(`
                            <div class="modal-header">
                                <h5 class="modal-title">${i18next.t('修改')}</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form class="validate-form" method="get" action="">
                                    ${renderColumn('edit', column)}
                                    <div class="mt-1" style="text-align: right">
                                        <button type="submit" class="btn btn-primary waves-effect waves-float waves-light">${i18next.t('确定')}</button>
                                    </div>
                                </form>
                            </div>
                        `);
                        initDetailEvent(selector, 'edit');
                        $(`${selector} form`).validate({
                            ignore: "",
                            rules: {
                                [column.name]: {
                                    required: true
                                },
                            },
                            submitHandler: function(form) {
                                console.info(form);
                                const formData = new FormData(form);

                                jiaogeiwo.http.post(`${api.updates}&ids=` + items.join(','), {
                                        [column.name]: formData.get(column.name)
                                    })
                                    .then(() => {
                                        deletes = {};
                                        $(`#${name} .page-checkbox`).prop('checked', false);
                                        $(`#${name} .check_all_div`).addClass('hidden');
                                        $(`#${name} .check_all_div .check_all_num`).text(0);
                                        $(`#${name} .check_all_div .check_query_all_num`).text(0);
                                        
                                        $(`#${name}-alone-edit-modal`).modal('hide');
                                        updateList();
                                    })
                            }
                        });
                        $(`#${name}-alone-edit-modal`).modal('show');
                    });

                    function assignValue(column, data, columns, selector) {
                        if (typeof column.set_val === 'function') {
                            column.set_val(data.detail, column, columns, selector);
                        } else {
                            if (column.type === 'textarea') {
                                $(selector + ` textarea[name="${column.name}"]`).val(data.detail[column.name]);
                            } else if (column.type === 'radio') {
                                if (data.detail[column.name]) {
                                    $(selector + ` input[name="${column.name}"][value="${data.detail[column.name]}"]`).attr('checked',true);
                                }
                            } else if (column.type === 'checkbox') {
                                if (data.detail[column.name] && data.detail[column.name].length > 0) {
                                    data.detail[column.name].forEach(value => {
                                        $(selector + ` input[name=${column.name}][value=${value}]`).attr('checked',true);
                                    });
                                }
                            } else if (column.type === 'select') {
                                if (data.detail[column.name]) {
                                    let select_arr = [];
                                    if (!(data.detail[column.name] instanceof Array)) {
                                        select_arr = [data.detail[column.name]];
                                    } else {
                                        select_arr = data.detail[column.name];
                                    }
                                    if (column.is_tag) { // 只有标签值的时候才加
                                        select_arr.filter(item => !column.data.find(it => (it.value || it) === item)).forEach(item => {
                                            $(selector + ` select[name=${column.name}]`).append(new Option(item, item, true, true));
                                        });
                                    }

                                    $(selector + ` select[name=${column.name}]`).select2('val', [data.detail[column.name]]);
                                    $(selector + ` select[name=${column.name}]`).trigger('change');
                                }
                            } else if (column.type === 'provinces') {
                                $(selector + ` select[name="${column.name}.province"]`).val(data.detail[column.name].province);
                                $(selector + ` select[name="${column.name}.province"]`).trigger('change');
                                $(selector + ` select[name="${column.name}.city"]`).val(data.detail[column.name].city);
                                $(selector + ` select[name="${column.name}.city"]`).trigger('change');
                                $(selector + ` select[name="${column.name}.area"]`).val(data.detail[column.name].area);
                            } else if (column.type === 'datetime-local') {
                                if (data.detail[column.name]) {
                                    const isodate = new Date(data.detail[column.name]);
                                    isodate.setMinutes(isodate.getMinutes() - isodate.getTimezoneOffset());
                                    $(selector + ` input[name="${column.name}"]`).val(isodate.toISOString().slice(0, 16));
                                }
                            } else if (column.type === 'date-range') {
                                if (data.detail[column.name]) {
                                    var fp = $(selector + ` input[name="${column.name}"]`)[0]._flatpickr;
                                    fp.setDate([data.detail[column.name].start_date, data.detail[column.name].end_date], false); 
                                }
                            } else if (column.type === 'file') {
                                const urls = data.detail[column.name];
                                if (urls) {
                                    $(`${selector} input[name="${column.name}"]`).val(urls);
                                    const $elem = $(`${selector} #${column.name}`);
                                    const dropzoneInst = $elem[0].dropzone;
                                    urls.forEach(url => {
                                        let mockFile = { name: url.substring(url.lastIndexOf('/') + 1), dataURL: url };
                                        dropzoneInst.files.push(mockFile);
                                        dropzoneInst.emit("addedfile", mockFile);
                                    });
                                    $elem.find('.dz-size').css('visibility', 'hidden');
                                    $elem.find('.dz-progress').css('visibility', 'hidden');
                                    $elem.find('.dz-filename [data-dz-name]').css('cursor', 'pointer');
                                    $elem.find('.dz-filename').click(function() {
                                        const index = $(this).closest('.dz-preview').index() - 1;
                                        window.open(urls[index], '_blank');
                                    })
                                }
                            } else if (column.type === 'single_file') {
                                $(`${selector} input[name="${column.name}"]`).attr('value', data.detail[column.name]);
                                $(`${selector} input[name="${column.name}"]`).closest('.media')
                                    .find('.img').attr('href', data.detail[column.name])
                                    .find('img').attr('src', data.detail[column.name]);
                                if (data.detail[column.name]) {
                                    $(`${selector} input[name="${column.name}"]`).closest('.media')
                                        .find('.custom-file-label').text(data.detail[column.name].substring(data.detail[column.name].lastIndexOf('/') + 1));
                                }
                                
                            } else if (column.type === 'image') {
                                $(`${selector} input[name="${column.name}"]`).attr('value', data.detail[column.name]);
                                $(`${selector} input[name="${column.name}"]`).closest('.media')
                                    .find('.img').attr('href', data.detail[column.name])
                                    .find('img').attr('src', data.detail[column.name]);
                                if (data.detail[column.name]) {
                                    $(`${selector} input[name="${column.name}"]`).closest('.media')
                                        .find('.custom-file-label').text(data.detail[column.name].substring(data.detail[column.name].lastIndexOf('/') + 1));
                                }
                            } else if (column.type === 'images') {
                                const urls = data.detail[column.name];
                                if (urls) {
                                    $(`${selector} input[name="${column.name}"]`).val(urls);
                                    const dropzoneInst = $(`${selector} #${column.name}`)[0].dropzone;
                                    urls.forEach(url => {
                                        let mockFile = { name: url.substring(url.lastIndexOf('/') + 1), dataURL: url.indexOf('.mp4') !== -1 ? `${url}?x-oss-process=video/snapshot,t_1000` : url };
                                        dropzoneInst.files.push(mockFile);
                                        dropzoneInst.emit("addedfile", mockFile);
                                        dropzoneInst.createThumbnailFromUrl(
                                            mockFile,
                                            dropzoneInst.options.thumbnailWidth, 
                                            dropzoneInst.options.thumbnailHeight,
                                            dropzoneInst.options.thumbnailMethod, true, function (thumbnail) {
                                                dropzoneInst.emit('thumbnail', mockFile, thumbnail);
                                            },
                                            'anonymous'
                                        );
                                        dropzoneInst.emit('complete', mockFile);
                                    })
                                }
                            } else if (column.type === 'repeater') {
                                var $repeater = $(`${selector} .${column.name}-repeater`).repeater({
                                    defaultValues: (column.children || []).filter(item => typeof item.default_value !== 'undefined').reduce((prev, curr) => {
                                        return {...prev, [column.name + '_' + curr.name]: curr.default_value}
                                    }, {}),
                                    show: function () {
                                        $(this).slideDown();
                                    },
                                    hide: function (deleteElement) {
                                        if (confirm(i18next.t('您确定要删除这行数据吗?'))) {
                                            $(this).slideUp(deleteElement);
                                        }
                                    }
                                })
                                if (data.detail[column.name] instanceof Array) {
                                    $repeater.setList(data.detail[column.name])
                                }
                                
                            } else if (column.type === 'richtext') {
                                window[`${column.name}EditorPromise`].then(edit => {
                                    edit.setData(data.detail[column.name]);
                                });
                            } else {
                                $(selector + ` input[name='${column.name}']`).val(data.detail[column.name]);
                            }
                        }
                    }
                    // 更新按钮
                    $(`#${name}`).on("click", '.item-view, .item-edit', function (event) {
                        event.preventDefault();
                        var type = $(event.currentTarget).hasClass('item-view') ? 'view' : 'update';
                        jiaogeiwo.http.get(`${api.detail}?id=${$(this).attr('uid')}`)
                            .then((data) => {
                                // custom event
                                if (typeof customEvent['detail-event'] === 'function') {
                                    customEvent['detail-event'](data);
                                }
                                
                                const content = renderColumns(type, data.detail);
                                const detailHtml = getDetail(type, `${i18next.t(type === 'view' ? '查看' : '修改')} ${i18next.t(moduleName) || moduleName}`, content);
                                const selector = `#${name}-modals-detail .modal-dialog`;
                                $(selector).html(detailHtml);
                                initDetailEvent(selector, type);
                                initDetailValidate(selector, type);
                                $(`#${name}-modals-detail`).modal('show');

                                // 赋值
                                $(selector + ' input[name=_id]').val(data.detail._id);
                                columns.filter(column => !!column.is_edit).forEach(column => {
                                    assignValue(column, data, columns, selector);
                                });
                            })
                    });

                    // 复制按钮
                    $(`#${name}`).on("click", '.item-copy', function (event) {
                        event.preventDefault();
                        var type = 'add';
                        jiaogeiwo.http.get(`${api.detail}?id=${$(this).attr('uid')}`)
                            .then((data) => {
                                // custom event
                                if (typeof customEvent['detail-event'] === 'function') {
                                    customEvent['detail-event'](data);
                                }
                                
                                const content = renderColumns(type, data.detail);
                                const detailHtml = getDetail(type, `${i18next.t('复制')} ${i18next.t(moduleName) || moduleName}`, content);
                                const selector = `#${name}-modals-detail .modal-dialog`;
                                $(selector).html(detailHtml);
                                initDetailEvent(selector, type);
                                initDetailValidate(selector, type);
                                $(`#${name}-modals-detail`).modal('show');

                                // 赋值
                                columns.filter(column => !!column.is_edit).forEach(column => {
                                    assignValue(column, data, columns, selector);
                                });
                            })
                    });

                    // 单个字段更新
                    $(`#${name}`).on("click", '.item-alone-edit', function (event) {
                        event.preventDefault();
                        jiaogeiwo.http.get(`${api.detail}?id=${$(this).attr('uid')}`)
                            .then((data) => {
                                const column = columns.find(item => item.name === $(this).attr('column_name'));
                                const selector = `#${name}-alone-edit-modal .modal-content`;
                                $(selector).html(`
                                    <div class="modal-header">
                                        <h5 class="modal-title">${i18next.t('修改')}</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <form class="validate-form" method="get" action="">
                                            ${renderColumn('edit', {...column, detail_class: 'col-12'})}
                                            <div class="mt-1" style="text-align: right">
                                                <button type="submit" class="btn btn-primary waves-effect waves-float waves-light">${i18next.t('确定')}</button>
                                            </div>
                                        </form>
                                    </div>
                                `);
                                initDetailEvent(selector, 'edit');

                                $(`${selector} form`).validate({
                                    ignore: "",
                                    rules: {
                                        [column.name]: {
                                            required: true
                                        },
                                    },
                                    submitHandler: function(form) {
                                        console.info(form);
                                        const formData = new FormData(form);
                                        
                                        jiaogeiwo.http.post(`${name}-update`, {
                                            _id: data.detail._id,
                                            [column.name]: formData.get(column.name)
                                        })
                                        .then(() => {
                                            $(`#${name}-alone-edit-modal`).modal('hide');
                                            updateList();
                                        });
                                    }
                                });
                                $(`#${name}-alone-edit-modal`).modal('show');

                                // 赋值
                                assignValue(column, data, columns, selector);
                            })
                    })

                    // 下载模版、导出数据
                    function downloadExcelFn(filename, paramsData) {
                        jiaogeiwo.http.post(`${api.list}?index=${paramsData.index}&size=${paramsData.size}`, {}, {showSuccess: false})
                            .then((data) => {
                                if (functions.downloadExcel) {
                                    functions.downloadExcel(data);
                                } else {
                                    const wb = XLSX.utils.book_new();

                                    const ws = XLSX.utils.json_to_sheet(data.list.map(item => {
                                        return columns.filter(item => item.is_edit).reduce((prev, curr) => {
                                            let value = item[curr.name] || '';
                                            if (curr.type === 'select' && curr.data && curr.data[0].value) { // 有key、value
                                                let arr = [];
                                                if (typeof item[curr.name] === 'string') {
                                                    arr = [item[curr.name]];
                                                } else if (item[curr.name] instanceof Array) {
                                                    arr = item[curr.name];
                                                }
                                                value = arr.map(it => (curr.data.find(i => i.value === it) || {}).name).join(',');
                                            } else if (curr.type === 'repeater') {
                                                if (item[curr.name] instanceof Array) {
                                                    value = item[curr.name].map(item => {
                                                        return (curr.children || []).map(child => {
                                                            return curr.name + '_' + child.name;
                                                        }).map(key => item[key]).join('=');
                                                    }).join('&');
                                                }
                                            } else {
                                                if (value instanceof Array) {
                                                    value = value.join(',');
                                                }
                                            }
                                            return {...prev, [curr.label]: value}
                                        }, {})
                                    }), {header: columns.filter(item => item.is_edit).map(item => item.label)});
            
                                    XLSX.utils.book_append_sheet(wb, ws, name);
            
                                    XLSX.writeFile(wb, filename);
                                }
                            })
                    }

                    // 下载模板
                    $(`#${name}`).on('click', '.download-tpl', function(event) {
                        event.preventDefault();

                        downloadExcelFn(`${name}导入模板.xlsx`, {index: 1, size: 1});
                    });

                    // 导出数据
                    $(`#${name}`).on('click', '.download-excel', function(event) {
                        event.preventDefault();
                        
                        downloadExcelFn(`${name}导出数据.xlsx`, {index: 1, size: 10000});
                        
                    });

                    // 导入数据(excel)
                    $(`#${name} #upload-excel-input`).change(e => {
                        const files = e.target.files;
                        const file = files[0];
                        const reader = new FileReader();
                        reader.onload = (e1) => {
                            const data = e1.target.result;
                            const workbook = XLSX.read(data, {type: 'binary'});
                            const worksheet = workbook.Sheets[name];
                            const rows = XLSX.utils.sheet_to_json(worksheet);
                            console.info(rows);
                            jiaogeiwo.http.post(api.adds, rows.map(item => {
                                const ret = {};
                                Object.keys(params_extra).forEach(key => {
                                    if (params_extra[key]) {
                                        ret[key] = params_extra[key];
                                    }
                                });
                                Object.keys(item).forEach(key => {
                                    const column = columns.find(c => c.label === key);
                                    if (column) {
                                        if (column.type === 'repeater' && item[key]) {
                                            ret[column.name] = item[key].split('&').map(item => item.split('=')).map(arr => {
                                                return column.children.reduce((prev, curr, index) => {
                                                    return {...prev, [`${column.name}_${curr.name}`]: arr[index]}
                                                }, {});
                                            });
                                        } else if (column.type === 'select') {
                                            let value = (column.data || []).find(it => (it.name || it) === item[key]);
                                            if (column.is_multiple) {
                                                value = item[key].split(',').map(itemkey => {
                                                    const obj = (column.data || []).find(it => (it.name || it) === itemkey);
                                                    return obj ? (obj.value || obj) : ''
                                                });
                                            }
                                            if (!value) {
                                                ret[column.name] = item[key];
                                            } else if (value instanceof Array) {
                                                ret[column.name] = value;
                                            } else {
                                                ret[column.name] = value.value || value;
                                            }
                                        } else {
                                            ret[column.name] = column.type !== 'number' ? `${item[key]}` : +item[key];
                                        }
                                    }
                                });
                                return ret;
                            }))
                            .then((data) => {
                                // custom event
                                if (typeof customEvent['adds-event'] === 'function') {
                                    customEvent['adds-event'](data);
                                }

                                updateList();
                            })
                        };
                        reader.readAsBinaryString(file);
                    })


                    // 导入文件夹
                    // 导入图片
                    function upload_dir_images(files, namekey, valuekey) {
                        const values = [];
                        for (let i = 0; i < files.length; i++) {
                            const file = files[i];
                            if (file.type.startsWith('image')) {
                                const dirname = file.webkitRelativePath.substring(file.webkitRelativePath.indexOf('/') + 1, file.webkitRelativePath.lastIndexOf('/'));
                                console.info(dirname);
                                const name = file.name.substring(0, file.name.lastIndexOf('.'));
                                values.push({
                                    file,
                                    data: {
                                        [namekey]: name,
                                    }
                                })
                            }
                        }
                        console.info(values);

                        let result = Promise.resolve();
                        values.forEach((item, index) => {
                            result = result.then(() => {
                                const fd = new FormData();
                                fd.append('file', item.file);
                                return fetch(`//yun-api.sungdell.com/upload-file?siteName=${jiaogeiwo.vars.project}`, {
                                    mode: 'cors',
                                    method: 'POST',
                                    body: fd,
                                }).then(res => {
                                    return res.json();
                                }).then(res => {
                                    console.log('res is',res);
                                    item.data[valuekey] = res.url;
                                    console.info(item.data);
                                });
                            })
                        });
                        return result.then(() => {
                            return values.map(item => {
                                return item.data;
                            })
                        })
                    }
                    // 导入word文档
                    function upload_dir_docxs(files, namekey, valuekey) {
                        console.info(files)
                        const values = [];
                        for (let i = 0; i < files.length; i++) {
                            const file = files[i];
                            if (file.webkitRelativePath.endsWith('docx')) {
                                const dirname = file.webkitRelativePath.substring(file.webkitRelativePath.indexOf('/') + 1, file.webkitRelativePath.lastIndexOf('/'));
                                console.info(dirname);
                                const name = file.name.substring(0, file.name.lastIndexOf('.'));
                                values.push({
                                    file,
                                    data: {
                                        [namekey]: name,
                                    }
                                })
                            }
                        }
                        console.info(values);

                        let result = Promise.resolve();
                        values.forEach((item, index) => {
                            result = result.then(() => {
                                const file = item.file;
                                console.info(file);
                                return new Promise((resolve, reject) => {
                                    const reader = new FileReader();
                                    reader.onload = function(loadEvent) {
                                        const arrayBuffer = loadEvent.target.result;
                                        mammoth.convertToHtml({arrayBuffer})
                                            .then((res) => {
                                                item.data[valuekey] = res.value;
                                                resolve();
                                            })
                                            .catch((e) => {
                                                console.error(e);
                                                resolve();
                                            })
                                            .done();
                                    };
                                    reader.readAsArrayBuffer(file);
                                })
                            })
                        })
                        return result.then(() => {
                            return values.map(item => {
                                return item.data;
                            })
                        })
                    }
                    $(`#${name}`).on('click', '.upload-dir', function(event) {
                        event.preventDefault();
                        const upload_columns = columns.filter(item => item.is_upload_dir);
                        const selector = `#${name}-upload-dir-modal .modal-content`;
                        $(selector).html(`
                            <div class="modal-header">
                                <h5 class="modal-title">${i18next.t('新增')}</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form class="validate-form" method="get" action="">
                                    ${upload_columns.map(column => {
                                        return renderColumn('add', {...column, detail_class: 'col-12'})
                                    }).join('\n')}
                                    <div class="col-12">
                                        <div class="form-group">
                                            <label class="d-block">上传文件类型<em>*</em></label>
                                            <div class="demo-inline-spacing">
                                                <div class="custom-control custom-radio my-50">
                                                    <input type="radio" id="upload_dir_filetype_1" name="upload_dir_filetype" value="img" class="custom-control-input" ${'img' === upload_dir_default.type ? 'checked' : ''}>
                                                    <label class="custom-control-label" for="upload_dir_filetype_1">${i18next.t('图片')}</label>
                                                </div>
                                                <div class="custom-control custom-radio my-50">
                                                    <input type="radio" id="upload_dir_filetype_2" name="upload_dir_filetype" value="document" class="custom-control-input" ${'document' === upload_dir_default.type ? 'checked' : ''}>
                                                    <label class="custom-control-label" for="upload_dir_filetype_2">${i18next.t('文档')}</label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-group">
                                            <label for="upload_dir_filename">文件名称对应字段<em>*</em></label>
                                            <select class="form-control" id="upload_dir_filename" name="upload_dir_filename">
                                                ${columns.filter(item => item.is_edit).map(item => {
                                                    return `<option value="${item.name}" ${item.name === upload_dir_default.name ? 'selected' : ''}>${item.label}</option>`
                                                })}
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-group">
                                            <label for="upload_dir_filecontent">文件内容对应字段<em>*</em></label>
                                            <select class="form-control" id="upload_dir_filecontent" name="upload_dir_filecontent">
                                                ${columns.filter(item => item.is_edit).map(item => {
                                                    return `<option value="${item.name}" ${item.name === upload_dir_default.content ? 'selected' : ''}>${item.label}</option>`
                                                })}
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-group">
                                            <label class="form-label">上传文件夹<em>*</em></label>
                                            <div class="custom-file">
                                                <input type="file" class="custom-file-input" id="upload_dir_file" name="upload_dir_file" multiple directory webkitdirectory="webkitdirectory">
                                                <label class="custom-file-label" for="upload_dir_file" data-browse="${i18next.t('浏览')}">${i18next.t('选择文件')}</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mt-1" style="text-align: right">
                                        <button type="submit" class="btn btn-primary waves-effect waves-float waves-light">${i18next.t('确定')}</button>
                                    </div>
                                </form>
                            </div>
                        `);
                        initDetailEvent(selector, 'add');

                        $(`${selector} form`).validate({
                            ignore: "",
                            rules: {
                                upload_dir_filetype: {
                                    required: true,
                                },
                                upload_dir_filename: {
                                    required: true,
                                },
                                upload_dir_filecontent: {
                                    required: true,
                                },
                                ...upload_columns.reduce((prev, curr) => {
                                    return {...prev, [curr.name]: curr.valid_rule}
                                }, {})
                            },
                            submitHandler: function(form) {
                                console.info(form);
                                const formData = new FormData(form);
                                Promise.resolve()
                                    .then(() => {
                                        const upload_dir_filename = formData.get('upload_dir_filename');
                                        const upload_dir_filecontent = formData.get('upload_dir_filecontent');
                                        if (formData.get('upload_dir_filetype') === 'img') {
                                            return upload_dir_images(form.upload_dir_file.files, upload_dir_filename, upload_dir_filecontent);
                                        }
                                        if (formData.get('upload_dir_filetype') === 'document') {
                                            return upload_dir_docxs(form.upload_dir_file.files, upload_dir_filename, upload_dir_filecontent);
                                        }
                                        return []
                                    })
                                    .then((values) => {
                                        if (values.length === 0) {
                                            alert(i18next.t('导入数据不能为空'));
                                            return;
                                        }
                                        const baseFormData = getFormDataByColumns(upload_columns, selector)
                                        return jiaogeiwo.http.post(api.adds, values.map(item => {
                                            return {...baseFormData, ...item};
                                        }))
                                        .then(() => {
                                            $(`#${name}-upload-dir-modal`).modal('hide');
                                            updateList();
                                        })
                                    })
                            }
                        });
                        $(`#${name}-upload-dir-modal`).modal('show');
                        
                    });

                })
                .then(() => {
                    return {
                        pageChange
                    }
                })
        },
    }
    // 模块相关
    const jiaogeiwo_mod = {
        instance: function () {
            return {
                list: () => {},
                delete: () => {},
                create: () => {},
                update: () => {},
                detail: () => {}
            }
        }
    };
    // 登录相关
    const jiaogeiwo_login = {};
    // 数据权限相关
    const jiaogeiwo_auth = {};
    
    // 收藏相关
    const jiaogeiwo_collect = {};
    // 订单相关
    const jiaogeiwo_order = {};
    // 物流相关
    const jiaogeiwo_tracking = {
        providers: {
            Austria: [{
                name: 'DPD Austria',
                value: 'dpd-at',
                preview: ''
            }, {
                name: 'post.at',
                value: 'post-at',
                preview: 'http://www.post.at/sendungsverfolgung.php?pnum1=${tracking_number}'
            }],
            Australia: [{
                name: 'Australia Post',
                value: 'australia-post',
                preview: 'http://auspost.com.au/track/track.html?id=${tracking_number}'
            }, {
                name: 'CouriersPlease',
                value: 'couriersplease',
                preview: 'https://www.couriersplease.com.au/tools-track/no/${tracking_number}'
            }, {
                name: 'Dai Post',
                value: 'dai-post',
                preview: 'https://daiglobaltrack.com/tracking.aspx?custtracknbr=${tracking_number}'
            }, {
                name: 'Fastway AU',
                value: 'fastway-au',
                preview: 'http://www.fastway.com.au/courier-services/track-your-parcel?l=${tracking_number}'
            }, {
                name: 'StarTrack',
                value: 'startrack',
                preview: 'https://startrack.com.au/track/details/${tracking_number}'
            }],
            Bulgaria: [
                {
                    name: 'Bulgaria Post',
                    value: 'bulgaria-post',
                    preview: 'https://www.bgpost.bg/IPSWebTracking/IPSWeb_item_events.asp?itemid=${tracking_number}'
                },
                {
                    name: 'Speedy',
                    value: 'speedy',
                    preview: 'https://www.speedy.bg/en/track-shipment?shipmentNumber=${tracking_number}'
                },
            ],
            Canada: [
                {
                    name: 'Canada Post',
                    value: 'canada-post',
                    preview: 'https://www.canadapost.ca/track-reperage/en#/search?searchFor=${tracking_number}'
                },
                {
                    name: 'Canpar',
                    value: 'canpar',
                    preview: 'https://www.canpar.ca/en/track/tracking.jsp'
                },
            ],
            Chile: [
                {
                    name: 'Correos Chile',
                    value: 'correos-chile',
                    preview: 'https://www.correos.cl/web/guest/seguimiento-en-linea?codigos=${tracking_number}'
                },
                {
                    name: 'Chilexpress',
                    value: 'chilexpress',
                    preview: 'https://chilexpress.cl/Views/ChilexpressCL/Resultado-busqueda.aspx?DATA=${tracking_number}'
                },
            ],
            China: [
                {
                    name: 'China Post',
                    value: 'china-post',
                    preview: 'http://english.chinapost.com.cn/html1/folder/1408/3929-1.htm?content=${tracking_number}'
                },
                {
                    name: 'EMS',
                    value: 'ems',
                    preview: 'https://www.ems.post/en/global-network/tracking'
                },
                {
                    name: 'Deppon',
                    value: 'deppon',
                    preview: 'https://www.deppon.com/en/toTrack.action'
                },
                {
                    name: 'Yun Express Tracking',
                    value: 'yunexpress',
                    preview: ''
                },
                {
                    name: 'Yanwen',
                    value: 'yanwen',
                    preview: 'http://track.yw56.com.cn/en-US'
                },
                {
                    name: 'wanbexpress',
                    value: 'wanbexpress',
                    preview: 'https://tracking.wanbexpress.com/?trackingNumbers=${tracking_number}'
                },
                {
                    name: 'JS EXPRESS',
                    value: 'js-express',
                    preview: 'http://www.js-exp.com/index.php?page=19'
                },
                {
                    name: 'SF EXPRESS',
                    value: 'sf',
                    preview: 'https://m.kuaidi100.com/result.jsp?nu=${tracking_number}'
                },
            ],
            Germany: [
                {
                    name: 'GLS Paket',
                    value: 'gls-paket',
                    preview: 'https://www.gls-pakete.de/sendungsverfolgung?match=${tracking_number}'
                },
                {
                    name: 'Cargoboard',
                    value: 'cargoboard',
                    preview: 'https://cargoboard.customer.cepra.de/Track/None?cRef=${tracking_number}'
                },
            ],
            Spain: [
                {
                    name: 'Correos España',
                    value: 'correos-spain',
                    preview: ''
                },
                {
                    name: 'DHL Spain',
                    value: 'dhl-es',
                    preview: ''
                },
                {
                    name: 'Redur Spain',
                    value: 'redur-es',
                    preview: ''
                },
                {
                    name: 'ENVIALIA',
                    value: 'envialia',
                    preview: 'https://www.envialia.com/tracking/'
                },
                {
                    name: 'Zeleris',
                    value: 'zeleris',
                    preview: 'https://www.zeleris.com'
                },
                {
                    name: 'Seur',
                    value: 'seur',
                    preview: 'https://www.seur.com/livetracking/pages/seguimiento-online-busqueda.do'
                },
            ],
            France: [
                {
                    name: 'GEODIS',
                    value: 'geodis',
                    preview: 'https://espace-client.geodis.com/services/destinataires/#/${tracking_number}/home'
                },
            ],
            'United Kingdom': [
                {
                    name: 'DHL Parcel UK',
                    value: 'dhl-parcel-uk',
                    preview: 'https://track.dhlparcel.co.uk/?con=${tracking_number}'
                },
                {
                    name: 'Swiship UK',
                    value: 'swiship-uk',
                    preview: 'https://www.swiship.co.uk/track/'
                },
            ],
            Global: [
                {
                    name: 'Hermes World',
                    value: 'hermes',
                    preview: ''
                },
                {
                    name: 'GLS Europe',
                    value: 'gls',
                    preview: ''
                },
                {
                    name: 'PostNL International 3S',
                    value: 'postnl-international-3s',
                    preview: 'https://www.internationalparceltracking.com/Main.aspx#/track/${tracking_number}/'
                },
                {
                    name: 'UPS',
                    value: 'ups',
                    preview: 'https://www.ups.com/track'
                },
                {
                    name: 'DHL',
                    value: 'dhl',
                    preview: 'https://webtrack.dhlglobalmail.com/?trackingnumber=${tracking_number}'
                },
                {
                    name: 'DB Schenker',
                    value: 'db-schenker',
                    preview: 'https://eschenker.dbschenker.com/nges-portal/public/si-SI_SI/#!/tracking/schenker-search?refNumber=${tracking_number}'
                },
                {
                    name: 'Raben',
                    value: 'raben',
                    preview: 'https://myraben.com/link/ShipmentInformation?Language=E01_ENGLISH&ShipmentNumber=${tracking_number}'
                },
                {
                    name: 'FedEx',
                    value: 'fedex',
                    preview: 'http://mailviewrecipient.fedex.com/recip_package_summary.aspx?PostalID=${tracking_number}'
                },
                {
                    name: 'Fetchr',
                    value: 'fetchr',
                    preview: 'hthttps://track.fetchr.us/track/${tracking_number}'
                },
            ],
            Greece: [
                {
                    name: 'Speedex Greece',
                    value: 'speedex-greece',
                    preview: 'http://www.speedex.gr/isapohi.asp?voucher_code=${tracking_number}&searcggo=Submit'
                },
            ],
            Ireland: [
                {
                    name: 'Fastway Ireland',
                    value: 'fastway-ireland',
                    preview: 'http://www.fastway.ie/courier-services/track-your-parcel?l=${tracking_number}'
                },
            ],
            Israel: [
                {
                    name: 'Israel Post He',
                    value: 'ilpost-he',
                    preview: ''
                },
                {
                    name: 'BOXIT',
                    value: 'boxit',
                    preview: 'http://portal.fcx.co.il/he/Track?shipmentNumber=${tracking_number}'
                },
                {
                    name: 'Orian',
                    value: 'orian',
                    preview: 'https://www.orian.com/OrianBarcodeTracking/?barcode=${tracking_number}'
                },
            ],
            India: [
                {
                    name: 'Xpressbees',
                    value: 'xpressbees',
                    preview: 'https://www.xpressbees.com/track?isawb=Yes&trackid=${tracking_number}'
                },
                {
                    name: 'Udaan Express',
                    value: 'udaan-express',
                    preview: 'https://udaanexpress.com/track/${tracking_number}'
                },
            ],
            Italy: [
                {
                    name: 'GLS Italy',
                    value: 'gls-italy',
                    preview: 'https://www.gls-italy.com/?option=com_gls&view=track_e_trace&mode=search&numero_spedizione=${tracking_number}&tipo_codice=nazionale'
                },
                {
                    name: 'Nexive',
                    value: 'nexive',
                    preview: 'https://tracking.nexive.it/?&b=${tracking_number}'
                },
            ],
            SriLanka: [
                {
                    name: 'Sri Lanka Post',
                    value: 'sri-lanka-post',
                    preview: 'https://globaltracktrace.ptc.post/gtt.web/'
                },
            ],
            Mexico: [
                {
                    name: 'Estafeta',
                    value: 'estafeta',
                    preview: 'https://www.estafeta.com/Herramientas/Rastreo'
                },
            ],
            Malaysia: [
                {
                    name: 'Malaysia Post',
                    value: 'malaysia-post',
                    preview: 'https://sendparcel.poslaju.com.my/open/trace?tno=${tracking_number}'
                },
                {
                    name: 'City-Link Express',
                    value: 'city-link-express',
                    preview: 'https://www.citylinkexpress.com/MY/Tracking.aspx'
                },
                {
                    name: 'GDEX',
                    value: 'gdex',
                    preview: 'https://www.gdexpress.com/malaysia/e-tracking/'
                },
                {
                    name: 'BEST Express',
                    value: 'best-my',
                    preview: ''
                },
            ],
            Namibia: [
                {
                    name: 'Nampost',
                    value: 'nampost',
                    preview: 'http://globaltracktrace.ptc.post/gtt.web/'
                },
            ],
            Netherlands: [
                {
                    name: 'GLS Netherlands',
                    value: 'gls-netherlands',
                    preview: 'https://www.gls-info.nl/tracking'
                },
            ],
            Philippines: [
                {
                    name: 'JT Express PH',
                    value: 'jt-express-ph',
                    preview: 'https://www.jtexpress.ph/index/query/gzquery.html?bills=${tracking_number}'
                },
            ],
            Poland: [
                {
                    name: 'Poland Post',
                    value: 'poland-post',
                    preview: 'https://emonitoring.poczta-polska.pl/?numer=${tracking_number}'
                },
                {
                    name: 'DHL Poland',
                    value: 'dhl-pl',
                    preview: ''
                },
                {
                    name: 'FedEx Poland',
                    value: 'fedex-pl',
                    preview: ''
                },
                {
                    name: 'DPD Poland',
                    value: 'dpd-pl',
                    preview: ''
                },
            ],
            Russia: [
                {
                    name: 'CDEK',
                    value: 'cdek',
                    preview: 'https://www.cdek.ru/ru/tracking?order_id=${tracking_number}'
                },
            ],
            Slovenia: [
                {
                    name: 'GLS Slovenia',
                    value: 'gls-slovenia',
                    preview: 'https://gls-group.eu/SI/sl/sledenje-posiljki?match=${tracking_number}'
                },
                {
                    name: 'DPD Slovenia',
                    value: 'dpd-si',
                    preview: ''
                },
            ],
            Slovakia: [
                {
                    name: 'Slovakia Post',
                    value: 'slovakia-post',
                    preview: 'https://www.sps-sro.sk/en/my-shipment/track-trace.html'
                },
            ],
            Turkey: [
                {
                    name: 'Yurtiçi Kargo',
                    value: 'yurtici-kargo',
                    preview: 'https://www.yurticikargo.com/tr/online-servisler/gonderi-sorgula?code=${tracking_number}'
                },
                {
                    name: 'Aras Kargo',
                    value: 'aras-kargo',
                    preview: 'https://www.araskargo.com.tr/tr/cargo_tracking_detail.aspx?kargo_takip_no=${tracking_number}'
                },
                {
                    name: 'MNG Kargo',
                    value: 'mng-kargo',
                    preview: 'http://service.mngkargo.com.tr/iactive/popup/kargotakip.asp?k=${tracking_number}'
                },
            ],
            'United States': [
                {
                    name: 'USPS',
                    value: 'usps',
                    preview: 'https://tools.usps.com/go/TrackConfirmAction?tLabels=${tracking_number}'
                },
                {
                    name: 'DHL US',
                    value: 'dhl-us',
                    preview: 'https://www.logistics.dhl/us-en/home/tracking/tracking-ecommerce.html?tracking-id=${tracking_number}'
                },
                {
                    name: 'Associated Global Systems',
                    value: 'associated-global-systems',
                    preview: 'https://tracking.agsystems.com/'
                },
                {
                    name: 'DHL Parcel',
                    value: 'dhl-parcel',
                    preview: 'https://www.logistics.dhl/us-en/home/tracking/tracking-ecommerce.html?tracking-id=${tracking_number}'
                },
                {
                    name: 'Old Dominion',
                    value: 'old-dominion',
                    preview: 'https://www.odfl.com/Trace/standardResult.faces?pro=${tracking_number}'
                },
            ],
            Vietnam: [
                {
                    name: 'Vietnam Post',
                    value: 'vietnam-post',
                    preview: 'http://www.vnpost.vn/en-us/dinh-vi/buu-pham?key=${tracking_number}'
                },
            ],
            'South Africa': [
                {
                    name: 'Vietnam Post',
                    value: 'vietnam-post',
                    preview: 'https://www.ram.co.za/Track/${tracking_number}'
                },
            ]
        }
    };
    // 地址相关
    const jiaogeiwo_countrys = {
        worlds: [{"name":"Afghanistan","short":"AF","state":[]},{"name":"Åland Islands","short":"AX","state":[]},{"name":"Albania","short":"AL"},{"name":"Algeria","short":"DZ","state":{"DZ-01":"Adrar","DZ-02":"Chlef","DZ-03":"Laghouat","DZ-04":"Oum El Bouaghi","DZ-05":"Batna","DZ-06":"Béjaïa","DZ-07":"Biskra","DZ-08":"Béchar","DZ-09":"Blida","DZ-10":"Bouira","DZ-11":"Tamanghasset","DZ-12":"Tébessa","DZ-13":"Tlemcen","DZ-14":"Tiaret","DZ-15":"Tizi Ouzou","DZ-16":"Algiers","DZ-17":"Djelfa","DZ-18":"Jijel","DZ-19":"Sétif","DZ-20":"Saïda","DZ-21":"Skikda","DZ-22":"Sidi Bel Abbès","DZ-23":"Annaba","DZ-24":"Guelma","DZ-25":"Constantine","DZ-26":"Médéa","DZ-27":"Mostaganem","DZ-28":"M’Sila","DZ-29":"Mascara","DZ-30":"Ouargla","DZ-31":"Oran","DZ-32":"El Bayadh","DZ-33":"Illizi","DZ-34":"Bordj Bou Arréridj","DZ-35":"Boumerdès","DZ-36":"El Tarf","DZ-37":"Tindouf","DZ-38":"Tissemsilt","DZ-39":"El Oued","DZ-40":"Khenchela","DZ-41":"Souk Ahras","DZ-42":"Tipasa","DZ-43":"Mila","DZ-44":"Aïn Defla","DZ-45":"Naama","DZ-46":"Aïn Témouchent","DZ-47":"Ghardaïa","DZ-48":"Relizane"}},{"name":"American Samoa","short":"AS"},{"name":"Andorra","short":"AD"},{"name":"Angola","short":"AO","state":{"BGO":"Bengo","BLU":"Benguela","BIE":"Bié","CAB":"Cabinda","CNN":"Cunene","HUA":"Huambo","HUI":"Huíla","CCU":"Kuando Kubango","CNO":"Kwanza-Norte","CUS":"Kwanza-Sul","LUA":"Luanda","LNO":"Lunda-Norte","LSU":"Lunda-Sul","MAL":"Malanje","MOX":"Moxico","NAM":"Namibe","UIG":"Uíge","ZAI":"Zaire"}},{"name":"Anguilla","short":"AI"},{"name":"Antarctica","short":"AQ"},{"name":"Antigua and Barbuda","short":"AG"},{"name":"Argentina","short":"AR","state":{"C":"Ciudad Autónoma de Buenos Aires","B":"Buenos Aires","K":"Catamarca","H":"Chaco","U":"Chubut","X":"Córdoba","W":"Corrientes","E":"Entre Ríos","P":"Formosa","Y":"Jujuy","L":"La Pampa","F":"La Rioja","M":"Mendoza","N":"Misiones","Q":"Neuquén","R":"Río Negro","A":"Salta","J":"San Juan","D":"San Luis","Z":"Santa Cruz","S":"Santa Fe","G":"Santiago del Estero","V":"Tierra del Fuego","T":"Tucumán"}},{"name":"Armenia","short":"AM"},{"name":"Aruba","short":"AW"},{"name":"Australia","short":"AU","state":{"ACT":"Australian Capital Territory","NSW":"New South Wales","NT":"Northern Territory","QLD":"Queensland","SA":"South Australia","TAS":"Tasmania","VIC":"Victoria","WA":"Western Australia"}},{"name":"Austria","short":"AT","state":[]},{"name":"Azerbaijan","short":"AZ"},{"name":"Bahamas","short":"BS"},{"name":"Bahrain","short":"BH","state":[]},{"name":"Bangladesh","short":"BD","state":{"BD-05":"Bagerhat","BD-01":"Bandarban","BD-02":"Barguna","BD-06":"Barishal","BD-07":"Bhola","BD-03":"Bogura","BD-04":"Brahmanbaria","BD-09":"Chandpur","BD-10":"Chattogram","BD-12":"Chuadanga","BD-11":"Cox's Bazar","BD-08":"Cumilla","BD-13":"Dhaka","BD-14":"Dinajpur","BD-15":"Faridpur ","BD-16":"Feni","BD-19":"Gaibandha","BD-18":"Gazipur","BD-17":"Gopalganj","BD-20":"Habiganj","BD-21":"Jamalpur","BD-22":"Jashore","BD-25":"Jhalokati","BD-23":"Jhenaidah","BD-24":"Joypurhat","BD-29":"Khagrachhari","BD-27":"Khulna","BD-26":"Kishoreganj","BD-28":"Kurigram","BD-30":"Kushtia","BD-31":"Lakshmipur","BD-32":"Lalmonirhat","BD-36":"Madaripur","BD-37":"Magura","BD-33":"Manikganj ","BD-39":"Meherpur","BD-38":"Moulvibazar","BD-35":"Munshiganj","BD-34":"Mymensingh","BD-48":"Naogaon","BD-43":"Narail","BD-40":"Narayanganj","BD-42":"Narsingdi","BD-44":"Natore","BD-45":"Nawabganj","BD-41":"Netrakona","BD-46":"Nilphamari","BD-47":"Noakhali","BD-49":"Pabna","BD-52":"Panchagarh","BD-51":"Patuakhali","BD-50":"Pirojpur","BD-53":"Rajbari","BD-54":"Rajshahi","BD-56":"Rangamati","BD-55":"Rangpur","BD-58":"Satkhira","BD-62":"Shariatpur","BD-57":"Sherpur","BD-59":"Sirajganj","BD-61":"Sunamganj","BD-60":"Sylhet","BD-63":"Tangail","BD-64":"Thakurgaon"}},{"name":"Barbados","short":"BB"},{"name":"Belarus","short":"BY"},{"name":"Belau","short":"PW"},{"name":"Belgium","short":"BE","state":[]},{"name":"Belize","short":"BZ"},{"name":"Benin","short":"BJ","state":{"AL":"Alibori","AK":"Atakora","AQ":"Atlantique","BO":"Borgou","CO":"Collines","KO":"Kouffo","DO":"Donga","LI":"Littoral","MO":"Mono","OU":"Ouémé","PL":"Plateau","ZO":"Zou"}},{"name":"Bermuda","short":"BM"},{"name":"Bhutan","short":"BT"},{"name":"Bolivia","short":"BO","state":{"B":"Chuquisaca","H":"Beni","C":"Cochabamba","L":"La Paz","O":"Oruro","N":"Pando","P":"Potosí","S":"Santa Cruz","T":"Tarija"}},{"name":"Bonaire, Saint Eustatius and Saba","short":"BQ"},{"name":"Bosnia and Herzegovina","short":"BA"},{"name":"Botswana","short":"BW"},{"name":"Bouvet Island","short":"BV"},{"name":"Brazil","short":"BR","state":{"AC":"Acre","AL":"Alagoas","AP":"Amapá","AM":"Amazonas","BA":"Bahia","CE":"Ceará","DF":"Distrito Federal","ES":"Espírito Santo","GO":"Goiás","MA":"Maranhão","MT":"Mato Grosso","MS":"Mato Grosso do Sul","MG":"Minas Gerais","PA":"Pará","PB":"Paraíba","PR":"Paraná","PE":"Pernambuco","PI":"Piauí","RJ":"Rio de Janeiro","RN":"Rio Grande do Norte","RS":"Rio Grande do Sul","RO":"Rondônia","RR":"Roraima","SC":"Santa Catarina","SP":"São Paulo","SE":"Sergipe","TO":"Tocantins"}},{"name":"British Indian Ocean Territory","short":"IO"},{"name":"Brunei","short":"BN"},{"name":"Bulgaria","short":"BG","state":{"BG-01":"Blagoevgrad","BG-02":"Burgas","BG-08":"Dobrich","BG-07":"Gabrovo","BG-26":"Haskovo","BG-09":"Kardzhali","BG-10":"Kyustendil","BG-11":"Lovech","BG-12":"Montana","BG-13":"Pazardzhik","BG-14":"Pernik","BG-15":"Pleven","BG-16":"Plovdiv","BG-17":"Razgrad","BG-18":"Ruse","BG-27":"Shumen","BG-19":"Silistra","BG-20":"Sliven","BG-21":"Smolyan","BG-23":"Sofia","BG-22":"Sofia-Grad","BG-24":"Stara Zagora","BG-25":"Targovishte","BG-03":"Varna","BG-04":"Veliko Tarnovo","BG-05":"Vidin","BG-06":"Vratsa","BG-28":"Yambol"}},{"name":"Burkina Faso","short":"BF"},{"name":"Burundi","short":"BI","state":[]},{"name":"Cambodia","short":"KH"},{"name":"Cameroon","short":"CM"},{"name":"Canada","short":"CA","state":{"AB":"Alberta","BC":"British Columbia","MB":"Manitoba","NB":"New Brunswick","NL":"Newfoundland and Labrador","NT":"Northwest Territories","NS":"Nova Scotia","NU":"Nunavut","ON":"Ontario","PE":"Prince Edward Island","QC":"Quebec","SK":"Saskatchewan","YT":"Yukon Territory"}},{"name":"Cape Verde","short":"CV"},{"name":"Cayman Islands","short":"KY"},{"name":"Central African Republic","short":"CF"},{"name":"Chad","short":"TD"},{"name":"Chile","short":"CL"},{"name":"China","short":"CN","state":{"CN1":"Yunnan / 云南","CN2":"Beijing / 北京","CN3":"Tianjin / 天津","CN4":"Hebei / 河北","CN5":"Shanxi / 山西","CN6":"Inner Mongolia / 內蒙古","CN7":"Liaoning / 辽宁","CN8":"Jilin / 吉林","CN9":"Heilongjiang / 黑龙江","CN10":"Shanghai / 上海","CN11":"Jiangsu / 江苏","CN12":"Zhejiang / 浙江","CN13":"Anhui / 安徽","CN14":"Fujian / 福建","CN15":"Jiangxi / 江西","CN16":"Shandong / 山东","CN17":"Henan / 河南","CN18":"Hubei / 湖北","CN19":"Hunan / 湖南","CN20":"Guangdong / 广东","CN21":"Guangxi Zhuang / 广西壮族","CN22":"Hainan / 海南","CN23":"Chongqing / 重庆","CN24":"Sichuan / 四川","CN25":"Guizhou / 贵州","CN26":"Shaanxi / 陕西","CN27":"Gansu / 甘肃","CN28":"Qinghai / 青海","CN29":"Ningxia Hui / 宁夏","CN30":"Macao / 澳门","CN31":"Tibet / 西藏","CN32":"Xinjiang / 新疆"}},{"name":"Christmas Island","short":"CX"},{"name":"Cocos (Keeling) Islands","short":"CC"},{"name":"Colombia","short":"CO"},{"name":"Comoros","short":"KM"},{"name":"Congo (Brazzaville)","short":"CG"},{"name":"Congo (Kinshasa)","short":"CD"},{"name":"Cook Islands","short":"CK"},{"name":"Costa Rica","short":"CR"},{"name":"Croatia","short":"HR"},{"name":"Cuba","short":"CU"},{"name":"Cura&ccedil;ao","short":"CW"},{"name":"Cyprus","short":"CY"},{"name":"Czech Republic","short":"CZ","state":[]},{"name":"Denmark","short":"DK","state":[]},{"name":"Djibouti","short":"DJ"},{"name":"Dominica","short":"DM"},{"name":"Dominican Republic","short":"DO","state":{"DO-01":"Distrito Nacional","DO-02":"Azua","DO-03":"Baoruco","DO-04":"Barahona","DO-05":"Dajabón","DO-06":"Duarte","DO-07":"Elías Piña","DO-08":"El Seibo","DO-09":"Espaillat","DO-10":"Independencia","DO-11":"La Altagracia","DO-12":"La Romana","DO-13":"La Vega","DO-14":"María Trinidad Sánchez","DO-15":"Monte Cristi","DO-16":"Pedernales","DO-17":"Peravia","DO-18":"Puerto Plata","DO-19":"Hermanas Mirabal","DO-20":"Samaná","DO-21":"San Cristóbal","DO-22":"San Juan","DO-23":"San Pedro de Macorís","DO-24":"Sánchez Ramírez","DO-25":"Santiago","DO-26":"Santiago Rodríguez","DO-27":"Valverde","DO-28":"Monseñor Nouel","DO-29":"Monte Plata","DO-30":"Hato Mayor","DO-31":"San José de Ocoa","DO-32":"Santo Domingo"}},{"name":"Ecuador","short":"EC"},{"name":"Egypt","short":"EG","state":{"EGALX":"Alexandria","EGASN":"Aswan","EGAST":"Asyut","EGBA":"Red Sea","EGBH":"Beheira","EGBNS":"Beni Suef","EGC":"Cairo","EGDK":"Dakahlia","EGDT":"Damietta","EGFYM":"Faiyum","EGGH":"Gharbia","EGGZ":"Giza","EGIS":"Ismailia","EGJS":"South Sinai","EGKB":"Qalyubia","EGKFS":"Kafr el-Sheikh","EGKN":"Qena","EGLX":"Luxor","EGMN":"Minya","EGMNF":"Monufia","EGMT":"Matrouh","EGPTS":"Port Said","EGSHG":"Sohag","EGSHR":"Al Sharqia","EGSIN":"North Sinai","EGSUZ":"Suez","EGWAD":"New Valley"}},{"name":"El Salvador","short":"SV"},{"name":"Equatorial Guinea","short":"GQ"},{"name":"Eritrea","short":"ER"},{"name":"Estonia","short":"EE","state":[]},{"name":"Ethiopia","short":"ET"},{"name":"Falkland Islands","short":"FK"},{"name":"Faroe Islands","short":"FO"},{"name":"Fiji","short":"FJ"},{"name":"Finland","short":"FI","state":[]},{"name":"France","short":"FR","state":[]},{"name":"French Guiana","short":"GF","state":[]},{"name":"French Polynesia","short":"PF"},{"name":"French Southern Territories","short":"TF"},{"name":"Gabon","short":"GA"},{"name":"Gambia","short":"GM"},{"name":"Georgia","short":"GE"},{"name":"Germany","short":"DE","state":[]},{"name":"Ghana","short":"GH","state":{"AF":"Ahafo","AH":"Ashanti","BA":"Brong-Ahafo","BO":"Bono","BE":"Bono East","CP":"Central","EP":"Eastern","AA":"Greater Accra","NE":"North East","NP":"Northern","OT":"Oti","SV":"Savannah","UE":"Upper East","UW":"Upper West","TV":"Volta","WP":"Western","WN":"Western North"}},{"name":"Gibraltar","short":"GI"},{"name":"Greece","short":"GR","state":{"I":"Attica","A":"East Macedonia and Thrace","B":"Central Macedonia","C":"West Macedonia","D":"Epirus","E":"Thessaly","F":"Ionian Islands","G":"West Greece","H":"Central Greece","J":"Peloponnese","K":"North Aegean","L":"South Aegean","M":"Crete"}},{"name":"Greenland","short":"GL"},{"name":"Grenada","short":"GD"},{"name":"Guadeloupe","short":"GP","state":[]},{"name":"Guam","short":"GU"},{"name":"Guatemala","short":"GT","state":{"AV":"Alta Verapaz","BV":"Baja Verapaz","CM":"Chimaltenango","CQ":"Chiquimula","PR":"El Progreso","ES":"Escuintla","GU":"Guatemala","HU":"Huehuetenango","IZ":"Izabal","JA":"Jalapa","JU":"Jutiapa","PE":"Petén","QZ":"Quetzaltenango","QC":"Quiché","RE":"Retalhuleu","SA":"Sacatepéquez","SM":"San Marcos","SR":"Santa Rosa","SO":"Sololá","SU":"Suchitepéquez","TO":"Totonicapán","ZA":"Zacapa"}},{"name":"Guernsey","short":"GG"},{"name":"Guinea","short":"GN"},{"name":"Guinea-Bissau","short":"GW"},{"name":"Guyana","short":"GY"},{"name":"Haiti","short":"HT"},{"name":"Heard Island and McDonald Islands","short":"HM"},{"name":"Honduras","short":"HN"},{"name":"Hong Kong","short":"HK","state":{"HONG KONG":"Hong Kong Island","KOWLOON":"Kowloon","NEW TERRITORIES":"New Territories"}},{"name":"Hungary","short":"HU","state":{"BK":"Bács-Kiskun","BE":"Békés","BA":"Baranya","BZ":"Borsod-Abaúj-Zemplén","BU":"Budapest","CS":"Csongrád-Csanád","FE":"Fejér","GS":"Győr-Moson-Sopron","HB":"Hajdú-Bihar","HE":"Heves","JN":"Jász-Nagykun-Szolnok","KE":"Komárom-Esztergom","NO":"Nógrád","PE":"Pest","SO":"Somogy","SZ":"Szabolcs-Szatmár-Bereg","TO":"Tolna","VA":"Vas","VE":"Veszprém","ZA":"Zala"}},{"name":"Iceland","short":"IS","state":[]},{"name":"India","short":"IN","state":{"AP":"Andhra Pradesh","AR":"Arunachal Pradesh","AS":"Assam","BR":"Bihar","CT":"Chhattisgarh","GA":"Goa","GJ":"Gujarat","HR":"Haryana","HP":"Himachal Pradesh","JK":"Jammu and Kashmir","JH":"Jharkhand","KA":"Karnataka","KL":"Kerala","LA":"Ladakh","MP":"Madhya Pradesh","MH":"Maharashtra","MN":"Manipur","ML":"Meghalaya","MZ":"Mizoram","NL":"Nagaland","OR":"Odisha","PB":"Punjab","RJ":"Rajasthan","SK":"Sikkim","TN":"Tamil Nadu","TS":"Telangana","TR":"Tripura","UK":"Uttarakhand","UP":"Uttar Pradesh","WB":"West Bengal","AN":"Andaman and Nicobar Islands","CH":"Chandigarh","DN":"Dadra and Nagar Haveli","DD":"Daman and Diu","DL":"Delhi","LD":"Lakshadeep","PY":"Pondicherry (Puducherry)"}},{"name":"Indonesia","short":"ID","state":{"AC":"Daerah Istimewa Aceh","SU":"Sumatera Utara","SB":"Sumatera Barat","RI":"Riau","KR":"Kepulauan Riau","JA":"Jambi","SS":"Sumatera Selatan","BB":"Bangka Belitung","BE":"Bengkulu","LA":"Lampung","JK":"DKI Jakarta","JB":"Jawa Barat","BT":"Banten","JT":"Jawa Tengah","JI":"Jawa Timur","YO":"Daerah Istimewa Yogyakarta","BA":"Bali","NB":"Nusa Tenggara Barat","NT":"Nusa Tenggara Timur","KB":"Kalimantan Barat","KT":"Kalimantan Tengah","KI":"Kalimantan Timur","KS":"Kalimantan Selatan","KU":"Kalimantan Utara","SA":"Sulawesi Utara","ST":"Sulawesi Tengah","SG":"Sulawesi Tenggara","SR":"Sulawesi Barat","SN":"Sulawesi Selatan","GO":"Gorontalo","MA":"Maluku","MU":"Maluku Utara","PA":"Papua","PB":"Papua Barat"}},{"name":"Iran","short":"IR","state":{"KHZ":"Khuzestan  (خوزستان)","THR":"Tehran  (تهران)","ILM":"Ilaam (ایلام)","BHR":"Bushehr (بوشهر)","ADL":"Ardabil (اردبیل)","ESF":"Isfahan (اصفهان)","YZD":"Yazd (یزد)","KRH":"Kermanshah (کرمانشاه)","KRN":"Kerman (کرمان)","HDN":"Hamadan (همدان)","GZN":"Ghazvin (قزوین)","ZJN":"Zanjan (زنجان)","LRS":"Luristan (لرستان)","ABZ":"Alborz (البرز)","EAZ":"East Azarbaijan (آذربایجان شرقی)","WAZ":"West Azarbaijan (آذربایجان غربی)","CHB":"Chaharmahal and Bakhtiari (چهارمحال و بختیاری)","SKH":"South Khorasan (خراسان جنوبی)","RKH":"Razavi Khorasan (خراسان رضوی)","NKH":"North Khorasan (خراسان شمالی)","SMN":"Semnan (سمنان)","FRS":"Fars (فارس)","QHM":"Qom (قم)","KRD":"Kurdistan / کردستان)","KBD":"Kohgiluyeh and BoyerAhmad (کهگیلوییه و بویراحمد)","GLS":"Golestan (گلستان)","GIL":"Gilan (گیلان)","MZN":"Mazandaran (مازندران)","MKZ":"Markazi (مرکزی)","HRZ":"Hormozgan (هرمزگان)","SBN":"Sistan and Baluchestan (سیستان و بلوچستان)"}},{"name":"Iraq","short":"IQ"},{"name":"Ireland","short":"IE","state":{"CW":"Carlow","CN":"Cavan","CE":"Clare","CO":"Cork","DL":"Donegal","D":"Dublin","G":"Galway","KY":"Kerry","KE":"Kildare","KK":"Kilkenny","LS":"Laois","LM":"Leitrim","LK":"Limerick","LD":"Longford","LH":"Louth","MO":"Mayo","MH":"Meath","MN":"Monaghan","OY":"Offaly","RN":"Roscommon","SO":"Sligo","TA":"Tipperary","WD":"Waterford","WH":"Westmeath","WX":"Wexford","WW":"Wicklow"}},{"name":"Isle of Man","short":"IM","state":[]},{"name":"Israel","short":"IL","state":[]},{"name":"Italy","short":"IT","state":{"AG":"Agrigento","AL":"Alessandria","AN":"Ancona","AO":"Aosta","AR":"Arezzo","AP":"Ascoli Piceno","AT":"Asti","AV":"Avellino","BA":"Bari","BT":"Barletta-Andria-Trani","BL":"Belluno","BN":"Benevento","BG":"Bergamo","BI":"Biella","BO":"Bologna","BZ":"Bolzano","BS":"Brescia","BR":"Brindisi","CA":"Cagliari","CL":"Caltanissetta","CB":"Campobasso","CE":"Caserta","CT":"Catania","CZ":"Catanzaro","CH":"Chieti","CO":"Como","CS":"Cosenza","CR":"Cremona","KR":"Crotone","CN":"Cuneo","EN":"Enna","FM":"Fermo","FE":"Ferrara","FI":"Firenze","FG":"Foggia","FC":"Forlì-Cesena","FR":"Frosinone","GE":"Genova","GO":"Gorizia","GR":"Grosseto","IM":"Imperia","IS":"Isernia","SP":"La Spezia","AQ":"L'Aquila","LT":"Latina","LE":"Lecce","LC":"Lecco","LI":"Livorno","LO":"Lodi","LU":"Lucca","MC":"Macerata","MN":"Mantova","MS":"Massa-Carrara","MT":"Matera","ME":"Messina","MI":"Milano","MO":"Modena","MB":"Monza e della Brianza","NA":"Napoli","NO":"Novara","NU":"Nuoro","OR":"Oristano","PD":"Padova","PA":"Palermo","PR":"Parma","PV":"Pavia","PG":"Perugia","PU":"Pesaro e Urbino","PE":"Pescara","PC":"Piacenza","PI":"Pisa","PT":"Pistoia","PN":"Pordenone","PZ":"Potenza","PO":"Prato","RG":"Ragusa","RA":"Ravenna","RC":"Reggio Calabria","RE":"Reggio Emilia","RI":"Rieti","RN":"Rimini","RM":"Roma","RO":"Rovigo","SA":"Salerno","SS":"Sassari","SV":"Savona","SI":"Siena","SR":"Siracusa","SO":"Sondrio","SU":"Sud Sardegna","TA":"Taranto","TE":"Teramo","TR":"Terni","TO":"Torino","TP":"Trapani","TN":"Trento","TV":"Treviso","TS":"Trieste","UD":"Udine","VA":"Varese","VE":"Venezia","VB":"Verbano-Cusio-Ossola","VC":"Vercelli","VR":"Verona","VV":"Vibo Valentia","VI":"Vicenza","VT":"Viterbo"}},{"name":"Ivory Coast","short":"CI"},{"name":"Jamaica","short":"JM","state":{"JM-01":"Kingston","JM-02":"Saint Andrew","JM-03":"Saint Thomas","JM-04":"Portland","JM-05":"Saint Mary","JM-06":"Saint Ann","JM-07":"Trelawny","JM-08":"Saint James","JM-09":"Hanover","JM-10":"Westmoreland","JM-11":"Saint Elizabeth","JM-12":"Manchester","JM-13":"Clarendon","JM-14":"Saint Catherine"}},{"name":"Japan","short":"JP","state":{"JP01":"Hokkaido","JP02":"Aomori","JP03":"Iwate","JP04":"Miyagi","JP05":"Akita","JP06":"Yamagata","JP07":"Fukushima","JP08":"Ibaraki","JP09":"Tochigi","JP10":"Gunma","JP11":"Saitama","JP12":"Chiba","JP13":"Tokyo","JP14":"Kanagawa","JP15":"Niigata","JP16":"Toyama","JP17":"Ishikawa","JP18":"Fukui","JP19":"Yamanashi","JP20":"Nagano","JP21":"Gifu","JP22":"Shizuoka","JP23":"Aichi","JP24":"Mie","JP25":"Shiga","JP26":"Kyoto","JP27":"Osaka","JP28":"Hyogo","JP29":"Nara","JP30":"Wakayama","JP31":"Tottori","JP32":"Shimane","JP33":"Okayama","JP34":"Hiroshima","JP35":"Yamaguchi","JP36":"Tokushima","JP37":"Kagawa","JP38":"Ehime","JP39":"Kochi","JP40":"Fukuoka","JP41":"Saga","JP42":"Nagasaki","JP43":"Kumamoto","JP44":"Oita","JP45":"Miyazaki","JP46":"Kagoshima","JP47":"Okinawa"}},{"name":"Jersey","short":"JE"},{"name":"Jordan","short":"JO"},{"name":"Kazakhstan","short":"KZ"},{"name":"Kenya","short":"KE","state":{"KE01":"Baringo","KE02":"Bomet","KE03":"Bungoma","KE04":"Busia","KE05":"Elgeyo-Marakwet","KE06":"Embu","KE07":"Garissa","KE08":"Homa Bay","KE09":"Isiolo","KE10":"Kajiado","KE11":"Kakamega","KE12":"Kericho","KE13":"Kiambu","KE14":"Kilifi","KE15":"Kirinyaga","KE16":"Kisii","KE17":"Kisumu","KE18":"Kitui","KE19":"Kwale","KE20":"Laikipia","KE21":"Lamu","KE22":"Machakos","KE23":"Makueni","KE24":"Mandera","KE25":"Marsabit","KE26":"Meru","KE27":"Migori","KE28":"Mombasa","KE29":"Murang’a","KE30":"Nairobi County","KE31":"Nakuru","KE32":"Nandi","KE33":"Narok","KE34":"Nyamira","KE35":"Nyandarua","KE36":"Nyeri","KE37":"Samburu","KE38":"Siaya","KE39":"Taita-Taveta","KE40":"Tana River","KE41":"Tharaka-Nithi","KE42":"Trans Nzoia","KE43":"Turkana","KE44":"Uasin Gishu","KE45":"Vihiga","KE46":"Wajir","KE47":"West Pokot"}},{"name":"Kiribati","short":"KI"},{"name":"Kuwait","short":"KW","state":[]},{"name":"Kyrgyzstan","short":"KG"},{"name":"Laos","short":"LA","state":{"AT":"Attapeu","BK":"Bokeo","BL":"Bolikhamsai","CH":"Champasak","HO":"Houaphanh","KH":"Khammouane","LM":"Luang Namtha","LP":"Luang Prabang","OU":"Oudomxay","PH":"Phongsaly","SL":"Salavan","SV":"Savannakhet","VI":"Vientiane Province","VT":"Vientiane","XA":"Sainyabuli","XE":"Sekong","XI":"Xiangkhouang","XS":"Xaisomboun"}},{"name":"Latvia","short":"LV"},{"name":"Lebanon","short":"LB","state":[]},{"name":"Lesotho","short":"LS"},{"name":"Liberia","short":"LR","state":{"BM":"Bomi","BN":"Bong","GA":"Gbarpolu","GB":"Grand Bassa","GC":"Grand Cape Mount","GG":"Grand Gedeh","GK":"Grand Kru","LO":"Lofa","MA":"Margibi","MY":"Maryland","MO":"Montserrado","NM":"Nimba","RV":"Rivercess","RG":"River Gee","SN":"Sinoe"}},{"name":"Libya","short":"LY"},{"name":"Liechtenstein","short":"LI"},{"name":"Lithuania","short":"LT"},{"name":"Luxembourg","short":"LU","state":[]},{"name":"Macao","short":"MO"},{"name":"Madagascar","short":"MG"},{"name":"Malawi","short":"MW"},{"name":"Malaysia","short":"MY","state":{"JHR":"Johor","KDH":"Kedah","KTN":"Kelantan","LBN":"Labuan","MLK":"Malacca (Melaka)","NSN":"Negeri Sembilan","PHG":"Pahang","PNG":"Penang (Pulau Pinang)","PRK":"Perak","PLS":"Perlis","SBH":"Sabah","SWK":"Sarawak","SGR":"Selangor","TRG":"Terengganu","PJY":"Putrajaya","KUL":"Kuala Lumpur"}},{"name":"Maldives","short":"MV"},{"name":"Mali","short":"ML"},{"name":"Malta","short":"MT","state":[]},{"name":"Marshall Islands","short":"MH"},{"name":"Martinique","short":"MQ","state":[]},{"name":"Mauritania","short":"MR"},{"name":"Mauritius","short":"MU"},{"name":"Mayotte","short":"YT","state":[]},{"name":"Mexico","short":"MX","state":{"DF":"Ciudad de México","JA":"Jalisco","NL":"Nuevo León","AG":"Aguascalientes","BC":"Baja California","BS":"Baja California Sur","CM":"Campeche","CS":"Chiapas","CH":"Chihuahua","CO":"Coahuila","CL":"Colima","DG":"Durango","GT":"Guanajuato","GR":"Guerrero","HG":"Hidalgo","MX":"Estado de México","MI":"Michoacán","MO":"Morelos","NA":"Nayarit","OA":"Oaxaca","PU":"Puebla","QT":"Querétaro","QR":"Quintana Roo","SL":"San Luis Potosí","SI":"Sinaloa","SO":"Sonora","TB":"Tabasco","TM":"Tamaulipas","TL":"Tlaxcala","VE":"Veracruz","YU":"Yucatán","ZA":"Zacatecas"}},{"name":"Micronesia","short":"FM"},{"name":"Moldova","short":"MD","state":{"C":"Chișinău","BL":"Bălți","AN":"Anenii Noi","BS":"Basarabeasca","BR":"Briceni","CH":"Cahul","CT":"Cantemir","CL":"Călărași","CS":"Căușeni","CM":"Cimișlia","CR":"Criuleni","DN":"Dondușeni","DR":"Drochia","DB":"Dubăsari","ED":"Edineț","FL":"Fălești","FR":"Florești","GE":"UTA Găgăuzia","GL":"Glodeni","HN":"Hîncești","IL":"Ialoveni","LV":"Leova","NS":"Nisporeni","OC":"Ocnița","OR":"Orhei","RZ":"Rezina","RS":"Rîșcani","SG":"Sîngerei","SR":"Soroca","ST":"Strășeni","SD":"Șoldănești","SV":"Ștefan Vodă","TR":"Taraclia","TL":"Telenești","UN":"Ungheni"}},{"name":"Monaco","short":"MC"},{"name":"Mongolia","short":"MN"},{"name":"Montenegro","short":"ME"},{"name":"Montserrat","short":"MS"},{"name":"Morocco","short":"MA"},{"name":"Mozambique","short":"MZ","state":{"MZP":"Cabo Delgado","MZG":"Gaza","MZI":"Inhambane","MZB":"Manica","MZL":"Maputo Province","MZMPM":"Maputo","MZN":"Nampula","MZA":"Niassa","MZS":"Sofala","MZT":"Tete","MZQ":"Zambézia"}},{"name":"Myanmar","short":"MM"},{"name":"Namibia","short":"NA","state":{"ER":"Erongo","HA":"Hardap","KA":"Karas","KE":"Kavango East","KW":"Kavango West","KH":"Khomas","KU":"Kunene","OW":"Ohangwena","OH":"Omaheke","OS":"Omusati","ON":"Oshana","OT":"Oshikoto","OD":"Otjozondjupa","CA":"Zambezi"}},{"name":"Nauru","short":"NR"},{"name":"Nepal","short":"NP","state":{"BAG":"Bagmati","BHE":"Bheri","DHA":"Dhaulagiri","GAN":"Gandaki","JAN":"Janakpur","KAR":"Karnali","KOS":"Koshi","LUM":"Lumbini","MAH":"Mahakali","MEC":"Mechi","NAR":"Narayani","RAP":"Rapti","SAG":"Sagarmatha","SET":"Seti"}},{"name":"Netherlands","short":"NL","state":[]},{"name":"New Caledonia","short":"NC"},{"name":"New Zealand","short":"NZ","state":{"NL":"Northland","AK":"Auckland","WA":"Waikato","BP":"Bay of Plenty","TK":"Taranaki","GI":"Gisborne","HB":"Hawke’s Bay","MW":"Manawatu-Wanganui","WE":"Wellington","NS":"Nelson","MB":"Marlborough","TM":"Tasman","WC":"West Coast","CT":"Canterbury","OT":"Otago","SL":"Southland"}},{"name":"Nicaragua","short":"NI"},{"name":"Niger","short":"NE"},{"name":"Nigeria","short":"NG","state":{"AB":"Abia","FC":"Abuja","AD":"Adamawa","AK":"Akwa Ibom","AN":"Anambra","BA":"Bauchi","BY":"Bayelsa","BE":"Benue","BO":"Borno","CR":"Cross River","DE":"Delta","EB":"Ebonyi","ED":"Edo","EK":"Ekiti","EN":"Enugu","GO":"Gombe","IM":"Imo","JI":"Jigawa","KD":"Kaduna","KN":"Kano","KT":"Katsina","KE":"Kebbi","KO":"Kogi","KW":"Kwara","LA":"Lagos","NA":"Nasarawa","NI":"Niger","OG":"Ogun","ON":"Ondo","OS":"Osun","OY":"Oyo","PL":"Plateau","RI":"Rivers","SO":"Sokoto","TA":"Taraba","YO":"Yobe","ZA":"Zamfara"}},{"name":"Niue","short":"NU"},{"name":"Norfolk Island","short":"NF"},{"name":"North Korea","short":"KP"},{"name":"North Macedonia","short":"MK"},{"name":"Northern Mariana Islands","short":"MP"},{"name":"Norway","short":"NO","state":[]},{"name":"Oman","short":"OM"},{"name":"Pakistan","short":"PK","state":{"JK":"Azad Kashmir","BA":"Balochistan","TA":"FATA","GB":"Gilgit Baltistan","IS":"Islamabad Capital Territory","KP":"Khyber Pakhtunkhwa","PB":"Punjab","SD":"Sindh"}},{"name":"Palestinian Territory","short":"PS"},{"name":"Panama","short":"PA"},{"name":"Papua New Guinea","short":"PG"},{"name":"Paraguay","short":"PY","state":{"PY-ASU":"Asunción","PY-1":"Concepción","PY-2":"San Pedro","PY-3":"Cordillera","PY-4":"Guairá","PY-5":"Caaguazú","PY-6":"Caazapá","PY-7":"Itapúa","PY-8":"Misiones","PY-9":"Paraguarí","PY-10":"Alto Paraná","PY-11":"Central","PY-12":"Ñeembucú","PY-13":"Amambay","PY-14":"Canindeyú","PY-15":"Presidente Hayes","PY-16":"Alto Paraguay","PY-17":"Boquerón"}},{"name":"Peru","short":"PE","state":{"CAL":"El Callao","LMA":"Municipalidad Metropolitana de Lima","AMA":"Amazonas","ANC":"Ancash","APU":"Apurímac","ARE":"Arequipa","AYA":"Ayacucho","CAJ":"Cajamarca","CUS":"Cusco","HUV":"Huancavelica","HUC":"Huánuco","ICA":"Ica","JUN":"Junín","LAL":"La Libertad","LAM":"Lambayeque","LIM":"Lima","LOR":"Loreto","MDD":"Madre de Dios","MOQ":"Moquegua","PAS":"Pasco","PIU":"Piura","PUN":"Puno","SAM":"San Martín","TAC":"Tacna","TUM":"Tumbes","UCA":"Ucayali"}},{"name":"Philippines","short":"PH","state":{"ABR":"Abra","AGN":"Agusan del Norte","AGS":"Agusan del Sur","AKL":"Aklan","ALB":"Albay","ANT":"Antique","APA":"Apayao","AUR":"Aurora","BAS":"Basilan","BAN":"Bataan","BTN":"Batanes","BTG":"Batangas","BEN":"Benguet","BIL":"Biliran","BOH":"Bohol","BUK":"Bukidnon","BUL":"Bulacan","CAG":"Cagayan","CAN":"Camarines Norte","CAS":"Camarines Sur","CAM":"Camiguin","CAP":"Capiz","CAT":"Catanduanes","CAV":"Cavite","CEB":"Cebu","COM":"Compostela Valley","NCO":"Cotabato","DAV":"Davao del Norte","DAS":"Davao del Sur","DAC":"Davao Occidental","DAO":"Davao Oriental","DIN":"Dinagat Islands","EAS":"Eastern Samar","GUI":"Guimaras","IFU":"Ifugao","ILN":"Ilocos Norte","ILS":"Ilocos Sur","ILI":"Iloilo","ISA":"Isabela","KAL":"Kalinga","LUN":"La Union","LAG":"Laguna","LAN":"Lanao del Norte","LAS":"Lanao del Sur","LEY":"Leyte","MAG":"Maguindanao","MAD":"Marinduque","MAS":"Masbate","MSC":"Misamis Occidental","MSR":"Misamis Oriental","MOU":"Mountain Province","NEC":"Negros Occidental","NER":"Negros Oriental","NSA":"Northern Samar","NUE":"Nueva Ecija","NUV":"Nueva Vizcaya","MDC":"Occidental Mindoro","MDR":"Oriental Mindoro","PLW":"Palawan","PAM":"Pampanga","PAN":"Pangasinan","QUE":"Quezon","QUI":"Quirino","RIZ":"Rizal","ROM":"Romblon","WSA":"Samar","SAR":"Sarangani","SIQ":"Siquijor","SOR":"Sorsogon","SCO":"South Cotabato","SLE":"Southern Leyte","SUK":"Sultan Kudarat","SLU":"Sulu","SUN":"Surigao del Norte","SUR":"Surigao del Sur","TAR":"Tarlac","TAW":"Tawi-Tawi","ZMB":"Zambales","ZAN":"Zamboanga del Norte","ZAS":"Zamboanga del Sur","ZSI":"Zamboanga Sibugay","00":"Metro Manila"}},{"name":"Pitcairn","short":"PN"},{"name":"Poland","short":"PL","state":[]},{"name":"Portugal","short":"PT","state":[]},{"name":"Puerto Rico","short":"PR","state":[]},{"name":"Qatar","short":"QA"},{"name":"Reunion","short":"RE","state":[]},{"name":"Romania","short":"RO","state":{"AB":"Alba","AR":"Arad","AG":"Argeș","BC":"Bacău","BH":"Bihor","BN":"Bistrița-Năsăud","BT":"Botoșani","BR":"Brăila","BV":"Brașov","B":"București","BZ":"Buzău","CL":"Călărași","CS":"Caraș-Severin","CJ":"Cluj","CT":"Constanța","CV":"Covasna","DB":"Dâmbovița","DJ":"Dolj","GL":"Galați","GR":"Giurgiu","GJ":"Gorj","HR":"Harghita","HD":"Hunedoara","IL":"Ialomița","IS":"Iași","IF":"Ilfov","MM":"Maramureș","MH":"Mehedinți","MS":"Mureș","NT":"Neamț","OT":"Olt","PH":"Prahova","SJ":"Sălaj","SM":"Satu Mare","SB":"Sibiu","SV":"Suceava","TR":"Teleorman","TM":"Timiș","TL":"Tulcea","VL":"Vâlcea","VS":"Vaslui","VN":"Vrancea"}},{"name":"Russia","short":"RU"},{"name":"Rwanda","short":"RW"},{"name":"S&atilde;o Tom&eacute; and Pr&iacute;ncipe","short":"ST"},{"name":"Saint Barth&eacute;lemy","short":"BL"},{"name":"Saint Helena","short":"SH"},{"name":"Saint Kitts and Nevis","short":"KN"},{"name":"Saint Lucia","short":"LC"},{"name":"Saint Martin (Dutch part)","short":"SX"},{"name":"Saint Martin (French part)","short":"MF"},{"name":"Saint Pierre and Miquelon","short":"PM"},{"name":"Saint Vincent and the Grenadines","short":"VC"},{"name":"Samoa","short":"WS"},{"name":"San Marino","short":"SM"},{"name":"Saudi Arabia","short":"SA"},{"name":"Senegal","short":"SN"},{"name":"Serbia","short":"RS","state":{"RS00":"Belgrade","RS14":"Bor","RS11":"Braničevo","RS02":"Central Banat","RS10":"Danube","RS23":"Jablanica","RS09":"Kolubara","RS08":"Mačva","RS17":"Morava","RS20":"Nišava","RS01":"North Bačka","RS03":"North Banat","RS24":"Pčinja","RS22":"Pirot","RS13":"Pomoravlje","RS19":"Rasina","RS18":"Raška","RS06":"South Bačka","RS04":"South Banat","RS07":"Srem","RS12":"Šumadija","RS21":"Toplica","RS05":"West Bačka","RS15":"Zaječar","RS16":"Zlatibor","RS25":"Kosovo","RS26":"Peć","RS27":"Prizren","RS28":"Kosovska Mitrovica","RS29":"Kosovo-Pomoravlje","RSKM":"Kosovo-Metohija","RSVO":"Vojvodina"}},{"name":"Seychelles","short":"SC"},{"name":"Sierra Leone","short":"SL"},{"name":"Singapore","short":"SG","state":[]},{"name":"Slovakia","short":"SK","state":[]},{"name":"Slovenia","short":"SI","state":[]},{"name":"Solomon Islands","short":"SB"},{"name":"Somalia","short":"SO"},{"name":"South Africa","short":"ZA","state":{"EC":"Eastern Cape","FS":"Free State","GP":"Gauteng","KZN":"KwaZulu-Natal","LP":"Limpopo","MP":"Mpumalanga","NC":"Northern Cape","NW":"North West","WC":"Western Cape"}},{"name":"South Georgia/Sandwich Islands","short":"GS"},{"name":"South Korea","short":"KR","state":[]},{"name":"South Sudan","short":"SS"},{"name":"Spain","short":"ES","state":{"C":"A Coruña","VI":"Araba/Álava","AB":"Albacete","A":"Alicante","AL":"Almería","O":"Asturias","AV":"Ávila","BA":"Badajoz","PM":"Baleares","B":"Barcelona","BU":"Burgos","CC":"Cáceres","CA":"Cádiz","S":"Cantabria","CS":"Castellón","CE":"Ceuta","CR":"Ciudad Real","CO":"Córdoba","CU":"Cuenca","GI":"Girona","GR":"Granada","GU":"Guadalajara","SS":"Gipuzkoa","H":"Huelva","HU":"Huesca","J":"Jaén","LO":"La Rioja","GC":"Las Palmas","LE":"León","L":"Lleida","LU":"Lugo","M":"Madrid","MA":"Málaga","ML":"Melilla","MU":"Murcia","NA":"Navarra","OR":"Ourense","P":"Palencia","PO":"Pontevedra","SA":"Salamanca","TF":"Santa Cruz de Tenerife","SG":"Segovia","SE":"Sevilla","SO":"Soria","T":"Tarragona","TE":"Teruel","TO":"Toledo","V":"Valencia","VA":"Valladolid","BI":"Biscay","ZA":"Zamora","Z":"Zaragoza"}},{"name":"Sri Lanka","short":"LK","state":[]},{"name":"Sudan","short":"SD"},{"name":"Suriname","short":"SR"},{"name":"Svalbard and Jan Mayen","short":"SJ"},{"name":"Swaziland","short":"SZ"},{"name":"Sweden","short":"SE","state":[]},{"name":"Switzerland","short":"CH","state":{"AG":"Aargau","AR":"Appenzell Ausserrhoden","AI":"Appenzell Innerrhoden","BL":"Basel-Landschaft","BS":"Basel-Stadt","BE":"Bern","FR":"Fribourg","GE":"Geneva","GL":"Glarus","GR":"Graubünden","JU":"Jura","LU":"Luzern","NE":"Neuchâtel","NW":"Nidwalden","OW":"Obwalden","SH":"Schaffhausen","SZ":"Schwyz","SO":"Solothurn","SG":"St. Gallen","TG":"Thurgau","TI":"Ticino","UR":"Uri","VS":"Valais","VD":"Vaud","ZG":"Zug","ZH":"Zürich"}},{"name":"Syria","short":"SY"},{"name":"Taiwan","short":"TW"},{"name":"Tajikistan","short":"TJ"},{"name":"Tanzania","short":"TZ","state":{"TZ01":"Arusha","TZ02":"Dar es Salaam","TZ03":"Dodoma","TZ04":"Iringa","TZ05":"Kagera","TZ06":"Pemba North","TZ07":"Zanzibar North","TZ08":"Kigoma","TZ09":"Kilimanjaro","TZ10":"Pemba South","TZ11":"Zanzibar South","TZ12":"Lindi","TZ13":"Mara","TZ14":"Mbeya","TZ15":"Zanzibar West","TZ16":"Morogoro","TZ17":"Mtwara","TZ18":"Mwanza","TZ19":"Coast","TZ20":"Rukwa","TZ21":"Ruvuma","TZ22":"Shinyanga","TZ23":"Singida","TZ24":"Tabora","TZ25":"Tanga","TZ26":"Manyara","TZ27":"Geita","TZ28":"Katavi","TZ29":"Njombe","TZ30":"Simiyu"}},{"name":"Thailand","short":"TH","state":{"TH-37":"Amnat Charoen","TH-15":"Ang Thong","TH-14":"Ayutthaya","TH-10":"Bangkok","TH-38":"Bueng Kan","TH-31":"Buri Ram","TH-24":"Chachoengsao","TH-18":"Chai Nat","TH-36":"Chaiyaphum","TH-22":"Chanthaburi","TH-50":"Chiang Mai","TH-57":"Chiang Rai","TH-20":"Chonburi","TH-86":"Chumphon","TH-46":"Kalasin","TH-62":"Kamphaeng Phet","TH-71":"Kanchanaburi","TH-40":"Khon Kaen","TH-81":"Krabi","TH-52":"Lampang","TH-51":"Lamphun","TH-42":"Loei","TH-16":"Lopburi","TH-58":"Mae Hong Son","TH-44":"Maha Sarakham","TH-49":"Mukdahan","TH-26":"Nakhon Nayok","TH-73":"Nakhon Pathom","TH-48":"Nakhon Phanom","TH-30":"Nakhon Ratchasima","TH-60":"Nakhon Sawan","TH-80":"Nakhon Si Thammarat","TH-55":"Nan","TH-96":"Narathiwat","TH-39":"Nong Bua Lam Phu","TH-43":"Nong Khai","TH-12":"Nonthaburi","TH-13":"Pathum Thani","TH-94":"Pattani","TH-82":"Phang Nga","TH-93":"Phatthalung","TH-56":"Phayao","TH-67":"Phetchabun","TH-76":"Phetchaburi","TH-66":"Phichit","TH-65":"Phitsanulok","TH-54":"Phrae","TH-83":"Phuket","TH-25":"Prachin Buri","TH-77":"Prachuap Khiri Khan","TH-85":"Ranong","TH-70":"Ratchaburi","TH-21":"Rayong","TH-45":"Roi Et","TH-27":"Sa Kaeo","TH-47":"Sakon Nakhon","TH-11":"Samut Prakan","TH-74":"Samut Sakhon","TH-75":"Samut Songkhram","TH-19":"Saraburi","TH-91":"Satun","TH-17":"Sing Buri","TH-33":"Sisaket","TH-90":"Songkhla","TH-64":"Sukhothai","TH-72":"Suphan Buri","TH-84":"Surat Thani","TH-32":"Surin","TH-63":"Tak","TH-92":"Trang","TH-23":"Trat","TH-34":"Ubon Ratchathani","TH-41":"Udon Thani","TH-61":"Uthai Thani","TH-53":"Uttaradit","TH-95":"Yala","TH-35":"Yasothon"}},{"name":"Timor-Leste","short":"TL"},{"name":"Togo","short":"TG"},{"name":"Tokelau","short":"TK"},{"name":"Tonga","short":"TO"},{"name":"Trinidad and Tobago","short":"TT"},{"name":"Tunisia","short":"TN"},{"name":"Turkey","short":"TR","state":{"TR01":"Adana","TR02":"Adıyaman","TR03":"Afyon","TR04":"Ağrı","TR05":"Amasya","TR06":"Ankara","TR07":"Antalya","TR08":"Artvin","TR09":"Aydın","TR10":"Balıkesir","TR11":"Bilecik","TR12":"Bingöl","TR13":"Bitlis","TR14":"Bolu","TR15":"Burdur","TR16":"Bursa","TR17":"Çanakkale","TR18":"Çankırı","TR19":"Çorum","TR20":"Denizli","TR21":"Diyarbakır","TR22":"Edirne","TR23":"Elazığ","TR24":"Erzincan","TR25":"Erzurum","TR26":"Eskişehir","TR27":"Gaziantep","TR28":"Giresun","TR29":"Gümüşhane","TR30":"Hakkari","TR31":"Hatay","TR32":"Isparta","TR33":"İçel","TR34":"İstanbul","TR35":"İzmir","TR36":"Kars","TR37":"Kastamonu","TR38":"Kayseri","TR39":"Kırklareli","TR40":"Kırşehir","TR41":"Kocaeli","TR42":"Konya","TR43":"Kütahya","TR44":"Malatya","TR45":"Manisa","TR46":"Kahramanmaraş","TR47":"Mardin","TR48":"Muğla","TR49":"Muş","TR50":"Nevşehir","TR51":"Niğde","TR52":"Ordu","TR53":"Rize","TR54":"Sakarya","TR55":"Samsun","TR56":"Siirt","TR57":"Sinop","TR58":"Sivas","TR59":"Tekirdağ","TR60":"Tokat","TR61":"Trabzon","TR62":"Tunceli","TR63":"Şanlıurfa","TR64":"Uşak","TR65":"Van","TR66":"Yozgat","TR67":"Zonguldak","TR68":"Aksaray","TR69":"Bayburt","TR70":"Karaman","TR71":"Kırıkkale","TR72":"Batman","TR73":"Şırnak","TR74":"Bartın","TR75":"Ardahan","TR76":"Iğdır","TR77":"Yalova","TR78":"Karabük","TR79":"Kilis","TR80":"Osmaniye","TR81":"Düzce"}},{"name":"Turkmenistan","short":"TM"},{"name":"Turks and Caicos Islands","short":"TC"},{"name":"Tuvalu","short":"TV"},{"name":"Uganda","short":"UG","state":{"UG314":"Abim","UG301":"Adjumani","UG322":"Agago","UG323":"Alebtong","UG315":"Amolatar","UG324":"Amudat","UG216":"Amuria","UG316":"Amuru","UG302":"Apac","UG303":"Arua","UG217":"Budaka","UG218":"Bududa","UG201":"Bugiri","UG235":"Bugweri","UG420":"Buhweju","UG117":"Buikwe","UG219":"Bukedea","UG118":"Bukomansimbi","UG220":"Bukwa","UG225":"Bulambuli","UG416":"Buliisa","UG401":"Bundibugyo","UG430":"Bunyangabu","UG402":"Bushenyi","UG202":"Busia","UG221":"Butaleja","UG119":"Butambala","UG233":"Butebo","UG120":"Buvuma","UG226":"Buyende","UG317":"Dokolo","UG121":"Gomba","UG304":"Gulu","UG403":"Hoima","UG417":"Ibanda","UG203":"Iganga","UG418":"Isingiro","UG204":"Jinja","UG318":"Kaabong","UG404":"Kabale","UG405":"Kabarole","UG213":"Kaberamaido","UG427":"Kagadi","UG428":"Kakumiro","UG101":"Kalangala","UG222":"Kaliro","UG122":"Kalungu","UG102":"Kampala","UG205":"Kamuli","UG413":"Kamwenge","UG414":"Kanungu","UG206":"Kapchorwa","UG236":"Kapelebyong","UG126":"Kasanda","UG406":"Kasese","UG207":"Katakwi","UG112":"Kayunga","UG407":"Kibaale","UG103":"Kiboga","UG227":"Kibuku","UG432":"Kikuube","UG419":"Kiruhura","UG421":"Kiryandongo","UG408":"Kisoro","UG305":"Kitgum","UG319":"Koboko","UG325":"Kole","UG306":"Kotido","UG208":"Kumi","UG333":"Kwania","UG228":"Kween","UG123":"Kyankwanzi","UG422":"Kyegegwa","UG415":"Kyenjojo","UG125":"Kyotera","UG326":"Lamwo","UG307":"Lira","UG229":"Luuka","UG104":"Luwero","UG124":"Lwengo","UG114":"Lyantonde","UG223":"Manafwa","UG320":"Maracha","UG105":"Masaka","UG409":"Masindi","UG214":"Mayuge","UG209":"Mbale","UG410":"Mbarara","UG423":"Mitooma","UG115":"Mityana","UG308":"Moroto","UG309":"Moyo","UG106":"Mpigi","UG107":"Mubende","UG108":"Mukono","UG334":"Nabilatuk","UG311":"Nakapiripirit","UG116":"Nakaseke","UG109":"Nakasongola","UG230":"Namayingo","UG234":"Namisindwa","UG224":"Namutumba","UG327":"Napak","UG310":"Nebbi","UG231":"Ngora","UG424":"Ntoroko","UG411":"Ntungamo","UG328":"Nwoya","UG331":"Omoro","UG329":"Otuke","UG321":"Oyam","UG312":"Pader","UG332":"Pakwach","UG210":"Pallisa","UG110":"Rakai","UG429":"Rubanda","UG425":"Rubirizi","UG431":"Rukiga","UG412":"Rukungiri","UG111":"Sembabule","UG232":"Serere","UG426":"Sheema","UG215":"Sironko","UG211":"Soroti","UG212":"Tororo","UG113":"Wakiso","UG313":"Yumbe","UG330":"Zombo"}},{"name":"Ukraine","short":"UA"},{"name":"United Arab Emirates","short":"AE"},{"name":"United Kingdom (UK)","short":"GB"},{"name":"United States (US)","short":"US","state":{"AL":"Alabama","AK":"Alaska","AZ":"Arizona","AR":"Arkansas","CA":"California","CO":"Colorado","CT":"Connecticut","DE":"Delaware","DC":"District Of Columbia","FL":"Florida","GA":"Georgia","HI":"Hawaii","ID":"Idaho","IL":"Illinois","IN":"Indiana","IA":"Iowa","KS":"Kansas","KY":"Kentucky","LA":"Louisiana","ME":"Maine","MD":"Maryland","MA":"Massachusetts","MI":"Michigan","MN":"Minnesota","MS":"Mississippi","MO":"Missouri","MT":"Montana","NE":"Nebraska","NV":"Nevada","NH":"New Hampshire","NJ":"New Jersey","NM":"New Mexico","NY":"New York","NC":"North Carolina","ND":"North Dakota","OH":"Ohio","OK":"Oklahoma","OR":"Oregon","PA":"Pennsylvania","RI":"Rhode Island","SC":"South Carolina","SD":"South Dakota","TN":"Tennessee","TX":"Texas","UT":"Utah","VT":"Vermont","VA":"Virginia","WA":"Washington","WV":"West Virginia","WI":"Wisconsin","WY":"Wyoming","AA":"Armed Forces (AA)","AE":"Armed Forces (AE)","AP":"Armed Forces (AP)"}},{"name":"United States (US) Minor Outlying Islands","short":"UM","state":{"67":"Johnston Atoll","71":"Midway Atoll","76":"Navassa Island","79":"Wake Island","81":"Baker Island","84":"Howland Island","86":"Jarvis Island","89":"Kingman Reef","95":"Palmyra Atoll"}},{"name":"Uruguay","short":"UY"},{"name":"Uzbekistan","short":"UZ"},{"name":"Vanuatu","short":"VU"},{"name":"Vatican","short":"VA"},{"name":"Venezuela","short":"VE"},{"name":"Vietnam","short":"VN","state":[]},{"name":"Virgin Islands (British)","short":"VG"},{"name":"Virgin Islands (US)","short":"VI"},{"name":"Wallis and Futuna","short":"WF"},{"name":"Western Sahara","short":"EH"},{"name":"Yemen","short":"YE"},{"name":"Zambia","short":"ZM","state":{"ZM-01":"Western","ZM-02":"Central","ZM-03":"Eastern","ZM-04":"Luapula","ZM-05":"Northern","ZM-06":"North-Western","ZM-07":"Southern","ZM-08":"Copperbelt","ZM-09":"Lusaka","ZM-10":"Muchinga"}},{"name":"Zimbabwe","short":"ZW"}]
    }
    // 仅中国
    // const jiaogeiwo_countrys = {
    //     worlds: [{"name":"中国","short":"CN","state":{"CN1":"Yunnan / 云南","CN2":"Beijing / 北京","CN3":"Tianjin / 天津","CN4":"Hebei / 河北","CN5":"Shanxi / 山西","CN6":"Inner Mongolia / 內蒙古","CN7":"Liaoning / 辽宁","CN8":"Jilin / 吉林","CN9":"Heilongjiang / 黑龙江","CN10":"Shanghai / 上海","CN11":"Jiangsu / 江苏","CN12":"Zhejiang / 浙江","CN13":"Anhui / 安徽","CN14":"Fujian / 福建","CN15":"Jiangxi / 江西","CN16":"Shandong / 山东","CN17":"Henan / 河南","CN18":"Hubei / 湖北","CN19":"Hunan / 湖南","CN20":"Guangdong / 广东","CN21":"Guangxi Zhuang / 广西壮族","CN22":"Hainan / 海南","CN23":"Chongqing / 重庆","CN24":"Sichuan / 四川","CN25":"Guizhou / 贵州","CN26":"Shaanxi / 陕西","CN27":"Gansu / 甘肃","CN28":"Qinghai / 青海","CN29":"Ningxia Hui / 宁夏","CN30":"Macao / 澳门","CN31":"Tibet / 西藏","CN32":"Xinjiang / 新疆"}}]
    // }

    // 短信相关
    const jiaogeiwo_sms = {
        requestId: null,
        init: function({phoneSelector, phoneCaptchaBtnSelector, areaCodeSelector}) {
            function daoshu() {
                var count = 60;
                $(phoneCaptchaBtnSelector).text(i18next.t('短信验证') + '(' + count + ')');
                var intervalId = setInterval(function() {
                    if (count > 0) {
                        $(phoneCaptchaBtnSelector).text(i18next.t('短信验证') + '(' + count + ')');
                        count--;
                    } else {
                        $(phoneCaptchaBtnSelector).text(i18next.t('重新获取'));
                        $(phoneCaptchaBtnSelector).removeClass('disabled');
                        clearInterval(intervalId); // 停止倒计时
                    }
                }, 1000);
            }
            $(phoneCaptchaBtnSelector).click(function() {
                const phone = $(phoneSelector).val()
                if (!phone) {
                    alert(i18next.t('请先填写手机号码'));
                    return;
                }
                if (!$(this).hasClass('disabled')) {
                    $(this).addClass('disabled');
                    const area_code = areaCodeSelector ? $(areaCodeSelector).val() : '86';
                    jiaogeiwo.http.get(`sms-${area_code === '86' ? 'send' : 'sendGlobe'}?phone=${(area_code === '86' ? '' : area_code) + phone}`)
                        .then((data) => {
                            console.info(data);
                            if (data.status === 0) {
                                jiaogeiwo_sms.requestId = data.requestId;
                                console.info('验证码发送成功，开始倒数');
                                daoshu();
                            } else {
                                alert(i18next.t(data.message));
                                $(phoneCaptchaBtnSelector).removeClass('disabled');
                            }
                        })
                        .catch((e) => {
                            console.info(e);
                            $(phoneCaptchaBtnSelector).removeClass('disabled');
                        })
                }
            })
        }
    }
    window.jiaogeiwo = {
        ...window.jiaogeiwo,
        vars: jiaogeiwo_vars,
        http: jiaogeiwo_http,
        common: jiaogeiwo_common,
        table: jiaogeiwo_table,
        mod: jiaogeiwo_mod,
        login: jiaogeiwo_login,
        auth: jiaogeiwo_auth,
        collect: jiaogeiwo_collect,
        order: jiaogeiwo_order,
        tracking: jiaogeiwo_tracking,
        countrys: jiaogeiwo_countrys,
        sms: jiaogeiwo_sms
    }

    
    // 触发jiaogeiwo初始化成功
    $(window).trigger('jiaogeiwo_load');
};


// 初始化语言
i18next.use(window.i18nextXHRBackend).use(window.i18nextBrowserLanguageDetector).init(
    {
      debug: true,
      fallbackLng: 'en',
      backend: {
        loadPath: '/jiaogeiwo/locales/{{lng}}.json'
      },
      returnObjects: true,
      detection: {
         order: ['querystring', 'cookie', 'localStorage', 'sessionStorage', 'htmlTag', 'navigator', 'path', 'subdomain'],
      }
    },
    function (err, t) {
      // resources have been loaded
      jqueryI18next.init(i18next, $);
      $('html').localize(); // 初始化静态页面

      // 加载flatpickr语言包
      $('body').append(`<script src="/jiaogeiwo/js/flatpickr/${i18next.language}.js"></script>`);

      // 加载
      if (i18next.language !== 'en') {
        $.extend($.validator.messages, {
            required: i18next.t("必填字段"),
            remote: i18next.t("请修正该字段"),
            email: i18next.t("请输入有效的电子邮件地址"),
            url: i18next.t("请输入有效的网址"),
            date: i18next.t("请输入有效的日期"),
            dateISO: i18next.t("请输入有效的日期 (YYYY-MM-DD)"),
            number: i18next.t("请输入有效的数字"),
            digits: i18next.t("只能输入数字"),
            creditcard: i18next.t("请输入有效的信用卡号码"),
            equalTo: i18next.t("你的输入不相同"),
            accept: i18next.t("请输入有效的后缀"),
            maxlength: jQuery.validator.format(i18next.t("最多可以输入 {0} 个字符")),
            minlength: jQuery.validator.format(i18next.t("最少要输入 {0} 个字符")),
            rangelength: jQuery.validator.format(i18next.t("请输入长度在 {0} 到 {1} 之间的字符串")),
            range: jQuery.validator.format(i18next.t("请输入范围在 {0} 到 {1} 之间的数值")),
            max: jQuery.validator.format(i18next.t("请输入不大于 {0} 的数值")),
            min: jQuery.validator.format(i18next.t("请输入不小于 {0} 的数值"))
          });
      }
      

      // 初始化jiaogiewo基础函数
      initJiaogeiwo(t);
      $('body').show();
    }
  );
// 语言设置和切换
var language = localStorage.getItem('i18nextLng');
if (language !== null) {
    if ($('.dropdown-language').length > 0) {
        // get the selected flag class
        var selectedLang = $('.dropdown-language').find('a[data-language=' + language + ']').text();
        var selectedFlag = $('.dropdown-language').find('a[data-language=' + language + '] .flag-icon').attr('class');
        // set the class in button
        $('#dropdown-flag .selected-language').text(selectedLang);
        $('#dropdown-flag .flag-icon').removeClass().addClass(selectedFlag);
    }
}
$('.dropdown-language .dropdown-item').on('click', function () {
    var $this = $(this);
    $this.siblings('.selected').removeClass('selected');
    $this.addClass('selected');
    var selectedLang = $this.text();
    var selectedFlag = $this.find('.flag-icon').attr('class');
    $('#dropdown-flag .selected-language').text(selectedLang);
    $('#dropdown-flag .flag-icon').removeClass().addClass(selectedFlag);
    var currentLanguage = $this.data('language');
    localStorage.setItem('changeI18nextLng', 'true');
    localStorage.setItem('i18nextLng', currentLanguage);
    location.reload();
});

// 设置页面变量
const is_server = true;