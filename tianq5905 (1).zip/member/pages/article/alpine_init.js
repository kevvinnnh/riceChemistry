document.addEventListener('alpine:init', () => {

    // 数据加载显示部分
    Alpine.store('detail', {
        data: {list: []},
        detail: {},
        list: {},
        and: {},
        sort: {
            name: '',
            type: ''
        },
        page: {
            index: 0,
            size: 10
        },
        count: 0,
        totalPages: 0,
        init() {
            // 一级分类
            jiaogeiwo.http.post('article_category-checklist' + location.search, {}, {
                    showSuccess: false
                })
                .then((data) => {
                    console.info(data);
                    this.data = data;

                    setTimeout(() => { // 高亮栏目
                        activeMenu('header', location.pathname.substring(1) + location.search, 'is-active');
                    }, 0);
                });

            const params = new URLSearchParams(location.search);
            if (params.get('id')) { // 详情页
                jiaogeiwo.http.get('article-checkdetail?id=' + params.get('id'))
                    .then((data) => {
                        console.info(data);
                        this.detail = data.detail;

                        setTimeout(() => { // 高亮栏目
                            const category_id = typeof (data.detail.categorys) === 'string' ? data.detail.categorys.replace('/', '') : data.detail.categorys[0].replace('/', '');
                            activeMenu('header', category_id, 'is-active');
                        }, 0);

                        // 初始化支付
                        Alpine.store('pay').initPay(this.detail);
                    })
            }

            if (params.get('c')) { // 列表页
                this.and['categorys'] = params.get('c');
                this.query(this.and, this.sort, this.page);
            }
            if (params.get('k')) { // 站内查询
                this.and['title'] = params.get('k');
                this.query(this.and, this.sort, this.page);
            }
        },
        getTop() { // 顶层分类
            return this.data.list.filter(item => !item.parent_id);
        },
        getChildren(item) { // 子分类
            return this.data.list.filter(child => child.parent_id === item.id);
        },
        filter(key, value) {
            this.and[key] = value;
            this.query(this.and, this.sort, this.page);
        },
        sortBy(key, value) {
            this.sort.name = key;
            this.sort.type = value;
            this.query(this.and, this.sort, this.page);
        },
        search(key, value) {
            this.and[key] = value;
            // console.info(value);
            this.query(this.and, this.sort, this.page);
        },
        getNews(size = 6) { // 获取最新的几条数据
            let news = [];
            (this.data.list || []).map(item => item.list).forEach(list => news = news.concat(list));
            return news.slice(0, size);
        },
        getCategoryName(tree_id) { // 获取分类名称，参数为字符串
            const category_id = tree_id.split('/').filter(item => item).pop();
            return (this.data.list.find(item => item._id === category_id) || '').name || '';
        },
        getCategoryNames(tree_ids) { // 获取分类名称，参数为数组
            return tree_ids.map(tree_id => {
                return this.getCategoryName(tree_id);
            })
        },
        getPageNums() {
            const current = this.page.index;
            const all_nums = Array.from({length: this.totalPages}, (item, index) => index);
            const start = all_nums.slice(0, 2);
            const middle = all_nums.slice(Math.max(2, current - 3), Math.min(all_nums.length - 2, Math.max(5, current + 2)));
            const end = all_nums.slice(all_nums.length - 2, all_nums.length);
            console.info(current, start, middle, end);
            if (all_nums < 6) {
                return all_nums;
            }
            if (middle[0] > 2) {
                start.push('.');
            }
            if (end[0] > (middle[middle.length - 1] + 1)) {
                middle.push('..');
            }
            return [...new Set([...start, ...middle, ...end])];
        },
        changePage(index) {
            this.page.index = index;
            this.query(this.and, this.sort, this.page);
        },
        query(and, sort, page) {
            const params = new URLSearchParams(location.search);
            jiaogeiwo.http.post(
                    'article-checklist?index=' + (page.index + 1) + '&size=' + page.size + '&sortName=' + sort.name + '&sortType=' + sort.type, {
                        and
                    }, {
                        showSuccess: false
                    })
                .then((data) => {
                    console.info(data);
                    this.list = data;
                    this.count = data.count;
                    this.totalPages = Math.ceil(data.count / page.size);
                })
        },
    });

    // 支付部分
    Alpine.store('pay', {
        is_pay: false,
        is_vip: false,
        article: null,
        is_show_pay: false,
        weixin_pay_info: {},
        pay_info: {},
        isWap() {
            return screen.availWidth < 768;
        },
        storePayInfo(key, value) {
            var payed_list = localStorage.getItem('payed_list') ? JSON.parse(localStorage.getItem('payed_list')) : {};
            payed_list[key] = value;
            localStorage.setItem('payed_list', JSON.stringify(payed_list));
        },
        pollPay(out_trade_no, timeout_second = 3000) {
            console.info(timeout_second);
            setTimeout(() => {
                jiaogeiwo.http.get('bill-search?out_trade_no=' + out_trade_no)
                    .then((data) => {
                        if (data.isFind) {
                            if (data.data.status === '已支付') {
                                this.storePayInfo(this.article._id, out_trade_no);
                                localStorage.removeItem('paying');
                                location.reload();
                                return;
                            }
                        }
                        console.info('未支付');
                        this.pollPay(out_trade_no, timeout_second > 10000 ? timeout_second : (timeout_second + 1000));
                    })
            }, timeout_second);
        },
        init() {
            if (this.isWap()) {
                if (localStorage.getItem('paying')) { // 正在支付
                    const paying = JSON.parse(localStorage.getItem('paying'));
                    if (paying.type === 'pay') {
                        this.pollPay(paying.out_trade_no);
                    }
                }
            }
        },
        initPay(article) {
            this.article = article;
            // 判断是否已经支付了
            var payed_list = localStorage.getItem('payed_list') ? JSON.parse(localStorage.getItem('payed_list')) : {};
            jiaogeiwo.http.get('article-isPay?out_trade_no=' + payed_list[article._id] + '&article_id=' + article._id)
                .then((data) => {
                    this.is_pay = data.is_pay;
                    this.is_vip = data.is_vip;
                    this.pay_info = data.detail || {};
                })
        },
        showPay() {
            console.info(this.article)
            // 默认微信支付
            if (this.isWap()) { // 手机浏览器
                jiaogeiwo.http.get('pay-getweixincodeh5?balance=' + this.article.view_price + '&description=' + this.article.title)
                    .then((data) => {
                        // 定时轮询
                        localStorage.setItem('paying', JSON.stringify({
                            out_trade_no: data.out_trade_no,
                            type: 'pay'
                        }));

                        location.href = data.h5_url;
                    })
            } else {
                jiaogeiwo.http.get('pay-getweixincode?balance=' + this.article.view_price + '&description=' + this.article.title)
                    .then((data) => {
                        this.is_show_pay = true;
                        this.weixin_pay_info = data;
                        // 定时轮询
                        this.pollPay(data.out_trade_no);
                    })
            }
        },
        showPoint(point, article_id) {
            jiaogeiwo.http.get('user-changePoint?point=' + point + '&article_id=' + article_id)
                .then(() => {
                    location.href = location.reload();
                })
        },
    })
})