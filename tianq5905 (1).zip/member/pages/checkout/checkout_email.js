function orderSuccess(order) {
// 发送邮件
var email_content = `
    <table style="border-spacing:0px;border-collapse:collapse;height:100%;width:100%">
        <tbody>
            <tr>
                <td>
                    <table style="width:100%;border-spacing:0px;border-collapse:collapse;margin:40px 0px 20px">
                        <tbody>
                            <tr>
                                <td>
                                    <center>

                                        <table
                                            style="width:560px;text-align:left;border-spacing:0px;border-collapse:collapse;margin:0px auto">
                                            <tbody>
                                                <tr>
                                                    <td>

                                                        <table
                                                            style="width:100%;border-spacing:0px;border-collapse:collapse">
                                                            <tbody>
                                                                <tr>
                                                                    <td>
                                                                        <h1
                                                                            style="font-weight:normal;font-size:30px;color:rgb(51,51,51);margin:0px">
                                                                            <a href="${location.origin}"
                                                                                style="font-size:30px;color:rgb(51,51,51);text-decoration:none"
                                                                                target="_blank" rel="noopener">Shop</a>
                                                                        </h1>
                                                                    </td>

                                                                    <td align="right">
                                                                        <span style="font-size:16px">
                                                                            Order ${order.order_id}
                                                                        </span>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>

                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>

                                    </center>
                                </td>
                            </tr>
                        </tbody>
                    </table>

                    <table style="width:100%;border-spacing:0px;border-collapse:collapse">
                        <tbody>
                            <tr>
                                <td>
                                    <center>
                                        <table
                                            style="width:560px;text-align:left;border-spacing:0px;border-collapse:collapse;margin:0px auto">
                                            <tbody>
                                                <tr>
                                                    <td>

                                                        <h2 style="font-weight:normal;font-size:24px;margin:0px 0px 10px">
                                                            Thank you for your purchase! </h2>
                                                        <p>


                                                            Hi d, we're getting your order ready to be shipped. We will
                                                            notify you when it has been sent.


                                                        </p>

                                                        <table
                                                            style="width:100%;border-spacing:0px;border-collapse:collapse;margin-top:20px">
                                                            <tbody>
                                                                <tr>
                                                                    <td>&nbsp;</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <table
                                                                            style="border-spacing:0px;border-collapse:collapse;float:left;margin-right:15px">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td align="center" bgcolor="#1990C6"><a
                                                                                            href="${location.origin}/member/pages/order/index.html"
                                                                                            style="font-size:16px;text-decoration:none;display:block;color:rgb(255,255,255);padding:20px 25px"
                                                                                            target="_blank"
                                                                                            rel="noopener">View your order</a></td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>

                                                                        <table
                                                                            style="border-spacing:0px;border-collapse:collapse;margin-top:19px">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td>or <a href="${location.origin}"
                                                                                            style="font-size:16px;text-decoration:none;color:rgb(25,144,198)"
                                                                                            target="_blank"
                                                                                            rel="noopener">Visit our
                                                                                            store</a>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>


                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </center>
                                </td>
                            </tr>
                        </tbody>
                    </table>




                    <table style="width:100%;border-spacing:0px;border-collapse:collapse">
                        <tbody>
                            <tr>
                                <td>
                                    <center>
                                        <table
                                            style="width:560px;text-align:left;border-spacing:0px;border-collapse:collapse;margin:0px auto">
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <h3 style="font-weight:normal;font-size:20px;margin:0px 0px 25px">
                                                            Order summary</h3>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <table
                                            style="width:560px;text-align:left;border-spacing:0px;border-collapse:collapse;margin:0px auto">
                                            <tbody>
                                                <tr>
                                                    <td>


                                                        <table
                                                            style="width:100%;border-spacing:0px;border-collapse:collapse">

                                                            <tbody>
                                                                ${order.items.map(({size, item}) => {
                                                                    return `
                                                                        <tr style="width:100%">
                                                                            <td>
                                                                                <table style="border-spacing:0px;border-collapse:collapse">
                                                                                    <tbody>
                                                                                        <tr>
                                                                                            <td>
                                                                                                <img src="${item.img}" align="left" width="60" height="60" style="margin-right: 15px; border-radius: 8px; border: 1px solid rgb(229, 229, 229);">
                                                                                            </td>
                                                                                            <td>
                                                                                                <span style="font-size:16px;font-weight:600;line-height:1.4;color:rgb(85,85,85)">${item.title}&nbsp;×&nbsp;${size}</span><br>
                                                                                                <span style="font-size:14px;color:rgb(153,153,153)">${item.intro || ''}</span><br>
                                                                                            </td>
                                                                                            <td><p align="right">${new Intl.NumberFormat('en-US', { style: 'currency', currency: localStorage.getItem('currency'), currencyDisplay: 'symbol' }).format(item.price)}</p></td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                            </td>
                                                                        </tr>
                                                                    `
                                                                }).join('\n')}
                                                                
                                                            </tbody>
                                                        </table>

                                                        <table
                                                            style="width:100%;border-spacing:0px;border-collapse:collapse;margin-top:15px;border-top:1px solid rgb(229,229,229)">
                                                            <tbody>
                                                                <tr>
                                                                    <td></td>
                                                                    <td>
                                                                        <table
                                                                            style="width:100%;border-spacing:0px;border-collapse:collapse;margin-top:20px">



                                                                            <tbody>
                                                                                <tr>
                                                                                    <td>
                                                                                        <p
                                                                                            style="color:rgb(119,119,119);line-height:1.2em;font-size:16px;margin:0px">
                                                                                            <span
                                                                                                style="font-size:16px">Subtotal</span>
                                                                                        </p>
                                                                                    </td>
                                                                                    <td align="right">
                                                                                        <strong
                                                                                            style="font-size:16px;color:rgb(85,85,85)">${new Intl.NumberFormat('en-US', { style: 'currency', currency: localStorage.getItem('currency'), currencyDisplay: 'symbol' }).format(order.fee.goods_fee)}</strong>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>
                                                                                        <p
                                                                                            style="color:rgb(119,119,119);line-height:1.2em;font-size:16px;margin:0px">
                                                                                            <span
                                                                                                style="font-size:16px">Shipping</span>
                                                                                        </p>
                                                                                    </td>
                                                                                    <td align="right">
                                                                                        <strong
                                                                                            style="font-size:16px;color:rgb(85,85,85)">${new Intl.NumberFormat('en-US', { style: 'currency', currency: localStorage.getItem('currency'), currencyDisplay: 'symbol' }).format(order.fee.shipping_fee)}</strong>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                        <table
                                                                            style="width:100%;border-spacing:0px;border-collapse:collapse;margin-top:20px;border-top:2px solid rgb(229,229,229)">

                                                                            <tbody>
                                                                                <tr>
                                                                                    <td>
                                                                                        <p
                                                                                            style="color:rgb(119,119,119);line-height:1.2em;font-size:16px;margin:0px">
                                                                                            <span
                                                                                                style="font-size:16px">Total</span>
                                                                                        </p>
                                                                                    </td>
                                                                                    <td align="right">
                                                                                        <strong
                                                                                            style="font-size:24px;color:rgb(85,85,85)">${new Intl.NumberFormat('en-US', { style: 'currency', currency: localStorage.getItem('currency'), currencyDisplay: 'symbol' }).format(order.fee.realpay_fee)}
                                                                                            USD</strong>
                                                                                    </td>
                                                                                </tr>

                                                                            </tbody>
                                                                        </table>








                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>


                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </center>
                                </td>
                            </tr>
                        </tbody>
                    </table>

                    <table style="width:100%;border-spacing:0px;border-collapse:collapse">
                        <tbody>
                            <tr>
                                <td>
                                    <center>
                                        <table
                                            style="width:560px;text-align:left;border-spacing:0px;border-collapse:collapse;margin:0px auto">
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <h3 style="font-weight:normal;font-size:20px;margin:0px 0px 25px">
                                                            Customer information</h3>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <table
                                            style="width:560px;text-align:left;border-spacing:0px;border-collapse:collapse;margin:0px auto">
                                            <tbody>
                                                <tr>
                                                    <td>

                                                        <table
                                                            style="width:100%;border-spacing:0px;border-collapse:collapse">
                                                            <tbody>
                                                                <tr>

                                                                    <td>
                                                                        <h4
                                                                            style="font-weight:500;font-size:16px;color:rgb(85,85,85);margin:0px 0px 5px">
                                                                            Shipping address</h4>
                                                                        <p>
                                                                        ${order.shipping.first_name} ${order.shipping.last_name}<br>
                                                                        ${order.shipping.address_1} ${order.shipping.address_2}<br>
                                                                        ${order.shipping.city} ${order.shipping.state} ${order.shipping.postcode}<br>
                                                                        ${order.shipping.country}
                                                                        </p>
                                                                    </td>


                                                                    <td>
                                                                        <h4
                                                                            style="font-weight:500;font-size:16px;color:rgb(85,85,85);margin:0px 0px 5px">
                                                                            Billing address</h4>
                                                                        <p>
                                                                        ${order.billing.first_name} ${order.billing.last_name}<br>
                                                                        ${order.billing.address_1} ${order.billing.address_2}<br>
                                                                        ${order.billing.city} ${order.billing.state} ${order.billing.postcode}<br>
                                                                        ${order.billing.country}
                                                                        </p>
                                                                    </td>

                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                        <table
                                                            style="width:100%;border-spacing:0px;border-collapse:collapse">
                                                            <tbody>
                                                                <tr>
                                                                    <td>
                                                                        <h4 style="font-weight:500;font-size:16px;color:rgb(85,85,85);margin:0px 0px 5px">Shipping method</h4>
                                                                        <p>Standard Shipping</p>
                                                                    </td>
                                                                    <td>
                                                                        <h4 style="font-weight:500;font-size:16px;color:rgb(85,85,85);margin:0px 0px 5px">Payment method</h4>
                                                                        <p>
                                                                            ${i18next.t(order.pay_info.pay_method)} — <strong style="font-size:16px;color:rgb(85,85,85)">${new Intl.NumberFormat('en-US', { style: 'currency', currency: localStorage.getItem('currency'), currencyDisplay: 'symbol' }).format(order.fee.realpay_fee)}</strong>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>

                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </center>
                                </td>
                            </tr>
                        </tbody>
                    </table>

                    <table style="width:100%;border-spacing:0px;border-collapse:collapse;border-top:1px solid rgb(229,229,229)">
                        <tbody>
                            <tr>
                                <td>
                                    <center>
                                        <table
                                            style="width:560px;text-align:left;border-spacing:0px;border-collapse:collapse;margin:0px auto">
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <p>If you have any questions, reply to this email or contact us at
                                                            <a href="mailto:{{send_email}}"
                                                                style="font-size:14px;text-decoration:none;color:rgb(25,144,198)"
                                                                target="_blank" rel="noopener">{{send_email}}</a></p>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </center>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
        </tbody>
    </table>
    `
    return jiaogeiwo.http.post('setting-sendMail', {
        "subject": `Order ${order.order_id} confirmed`,
        "email": order.email,
        "content": email_content
    }, {showSuccess: false})
}

// 通知管理员
function notificationAdmin(subject, content, receivemail) {
    // 发送邮件
    var email_content = `
    <table style="border-spacing:0px;border-collapse:collapse;height:100%;width:100%">
        <tbody>
            <tr>
                <td>
                    <p style="font-weight: 600; font-size: 18px; margin-bottom: 0;">Hey</p>
                    
                    <p class="sm-leading-32" style="font-weight: 600; font-size: 20px; margin: 0 0 16px; --text-opacity: 1; color: #263238; color: rgba(38, 50, 56, var(--text-opacity));">
                        ${content}
                    </p>
                </td>
            </tr>
        </tbody>
    </table>
    `
    return jiaogeiwo.http.post('setting-sendMail', {
        "subject": subject,
        "email": receivemail.email,
        "content": email_content
    }, {showSuccess: false})
}