const baseMenus = [
    {
        name: '首页',
        link: '/member/index.html',
        extraLinks: ['/member/'],
        icon: 'home'
    },
    // {
    //     name: '个人中心',
    //     link: '/member/pages/user/index.html',
    //     icon: 'user',
    //     children: [
    //         {
    //             name: '基本信息',
    //             link: '/member/pages/user/index.html',
    //             icon: 'circle',
    //         },
    //         {
    //             name: '实名认证',
    //             link: '/member/pages/user/verified.html',
    //             icon: 'circle',
    //         },
    //         {
    //             name: '充值提现',
    //             link: '/member/pages/user/cost.html',
    //             icon: 'circle',
    //         },
    //         {
    //             name: '积分明细',
    //             link: '/member/pages/user/point_log.html',
    //             icon: 'circle',
    //         }
    //     ]
    // }, 
    // {
    //     name: '订单管理',
    //     link: '/member/pages/order/index.html',
    //     icon: 'shopping-cart'
    // }, 
    // {
    //     name: '文章管理',
    //     link: '/member/pages/article/index.html',
    //     icon: 'clipboard',
    //     children: [
    //         {
    //             name: '文章列表',
    //             link: '/member/pages/article/index.html',
    //             icon: 'circle',
    //         },
    //         {
    //             name: '购买的文档',
    //             link: '/member/pages/article/buy.html',
    //             icon: 'circle',
    //         }
    //     ]
    // }, 
    // {
    //     name: '邀请中心',
    //     link: '/member/pages/invite/index.html',
    //     icon: 'user-plus'
    // }, 
    // {
    //     name: '支付记录',
    //     link: '/member/pages/bill/index.html',
    //     icon: 'dollar-sign'
    // }, 
    // {
    //     name: '在线客服',
    //     link: '/member/pages/chat/index.html',
    //     icon: 'message-square'
    // }, 
    {
        name: '返回首页',
        link: '/',
        icon: 'home'
    },
];
let menus = [...baseMenus];
// let menus = [];
// // if (user.role === '') {
// //     menus = [...baseMenus, {}]   
// // }
document.write(`
    <!-- BEGIN: Header-->
    <nav
        class="header-navbar navbar navbar-expand-lg align-items-center floating-nav navbar-light navbar-shadow container-xxl">
        <div class="navbar-container d-flex content">
            <div class="bookmark-wrapper d-flex align-items-center">
                <ul class="nav navbar-nav d-xl-none">
                    <li class="nav-item"><a class="nav-link menu-toggle" href="javascript:void(0);"><i class="ficon" data-feather="menu"></i></a></li>
                </ul>
                <ul class="nav navbar-nav bookmark-icons">
                    <li class="nav-item d-none d-lg-block">
                        <a class="nav-link" href="/member/pages/user/index.html" data-toggle="tooltip" data-placement="top" data-i18n="[title]个人中心"><i class="ficon" data-feather="user"></i></a>
                    </li>
                    <li class="nav-item d-none d-lg-block">
                        <a class="nav-link" href="/member/pages/order/index.html" data-toggle="tooltip" data-placement="top" data-i18n="[title]订单管理"><i class="ficon" data-feather="shopping-cart"></i></a>
                    </li>
                    <li class="nav-item d-none d-lg-block">
                        <a class="nav-link" href="/member/pages/chat/index.html" data-toggle="tooltip" data-placement="top" data-i18n="[title]在线客服"><i class="ficon" data-feather="message-square"></i></a>
                    </li>
                </ul>
                
            </div>
            <ul class="nav navbar-nav align-items-center ml-auto">
                <li class="nav-item dropdown dropdown-language">
                    <a class="nav-link dropdown-toggle" id="dropdown-flag" href="javascript:void(0);"
                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="flag-icon flag-icon-us"></i><span class="selected-language">English</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdown-flag">
                        <a class="dropdown-item" href="javascript:void(0);" data-language="zh-CN"><i
                            class="flag-icon flag-icon-cn"></i> 中文</a>
                        <a class="dropdown-item" href="javascript:void(0);" data-language="en"><i
                                class="flag-icon flag-icon-us"></i> English</a>
                        <a class="dropdown-item" href="javascript:void(0);" data-language="jp"><i
                            class="flag-icon flag-icon-jp"></i> Japan</a>
                        <a class="dropdown-item" href="javascript:void(0);" data-language="es"><i
                            class="flag-icon flag-icon-es"></i> España </a>
                        <a class="dropdown-item" href="javascript:void(0);" data-language="pl"><i
                            class="flag-icon flag-icon-pl"></i> Polska </a>
                        <a class="dropdown-item" href="javascript:void(0);" data-language="ru"><i
                            class="flag-icon flag-icon-ru"></i> Russia </a>
                        <a class="dropdown-item" href="javascript:void(0);" data-language="fr"><i
                                class="flag-icon flag-icon-fr"></i> French </a>
                        <a class="dropdown-item" href="javascript:void(0);" data-language="pt"><i
                                class="flag-icon flag-icon-pt"></i> Portugal </a>
                    </div>
                </li>
                <li class="nav-item d-none d-lg-block"><a class="nav-link nav-link-style"><i class="ficon"
                    data-feather="moon"></i></a></li>
                    <li class="nav-item dropdown dropdown-user">
                    <a class="nav-link dropdown-toggle dropdown-user-link" id="dropdown-user" href="javascript:void(0);" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <div class="user-nav d-sm-flex d-none">
                            <span class="user-name font-weight-bolder"><script>document.write(user.name)</script></span>
                            <script>user.role ? document.write('<span class="user-status"><span>' + user.role + '</span></span>') : ''</script>
                            <script>(!user.role && user.grade) ? document.write('<span class="user-status" data-i18n="' + user.grade + '"><span>' + user.grade + '</span></span>') : ''</script>
                        </div>
                        <span class="avatar">
                            <script>document.write('<img class="round" src="' + user.avatar + '" alt="avatar" height="40" width="40" style="object-fit: cover;">')</script>
                            <span class="avatar-status-online"></span>
                        </span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdown-user" style="width: 13rem;">
                        <a class="dropdown-item" href="/member/pages/user/index.html"><i class="mr-50" data-feather="user"></i> <span data-i18n="个人中心"></span></a>
                        <a class="dropdown-item" href="/member/pages/order/index.html"><i class="mr-50" data-feather="shopping-cart"></i> <span data-i18n="订单管理"></span></a>
                        <a class="dropdown-item" href="/member/pages/chat/index.html"><i class="mr-50" data-feather="message-square"></i> <span data-i18n="在线客服"></span></a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="javascript:logout();"><i class="mr-50" data-feather="power"></i> <span data-i18n="注销"></span></a>
                    </div>
                </li>
            </ul>
        </div>
    </nav>
    <!-- END: Header-->
    <!-- BEGIN: Main Menu-->
    <div class="main-menu menu-fixed menu-dark menu-accordion menu-shadow" data-scroll-to-active="true">
        <div class="navbar-header">
            <ul class="nav navbar-nav flex-row">
                <li class="nav-item mr-auto">
                    <a class="navbar-brand" href="/">
                        <span class="brand-logo">
                            <svg viewbox="0 0 139 95" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="24">
                                <defs>
                                    <lineargradient id="linearGradient-1" x1="100%" y1="10.5120544%" x2="50%" y2="89.4879456%">
                                        <stop stop-color="#000000" offset="0%"></stop>
                                        <stop stop-color="#FFFFFF" offset="100%"></stop>
                                    </lineargradient>
                                    <lineargradient id="linearGradient-2" x1="64.0437835%" y1="46.3276743%" x2="37.373316%" y2="100%">
                                        <stop stop-color="#EEEEEE" stop-opacity="0" offset="0%"></stop>
                                        <stop stop-color="#FFFFFF" offset="100%"></stop>
                                    </lineargradient>
                                </defs>
                                <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                    <g id="Artboard" transform="translate(-400.000000, -178.000000)">
                                        <g id="Group" transform="translate(400.000000, 178.000000)">
                                            <path class="text-primary" id="Path" d="M-5.68434189e-14,2.84217094e-14 L39.1816085,2.84217094e-14 L69.3453773,32.2519224 L101.428699,2.84217094e-14 L138.784583,2.84217094e-14 L138.784199,29.8015838 C137.958931,37.3510206 135.784352,42.5567762 132.260463,45.4188507 C128.736573,48.2809251 112.33867,64.5239941 83.0667527,94.1480575 L56.2750821,94.1480575 L6.71554594,44.4188507 C2.46876683,39.9813776 0.345377275,35.1089553 0.345377275,29.8015838 C0.345377275,24.4942122 0.230251516,14.560351 -5.68434189e-14,2.84217094e-14 Z" style="fill:currentColor"></path>
                                            <path id="Path1" d="M69.3453773,32.2519224 L101.428699,1.42108547e-14 L138.784583,1.42108547e-14 L138.784199,29.8015838 C137.958931,37.3510206 135.784352,42.5567762 132.260463,45.4188507 C128.736573,48.2809251 112.33867,64.5239941 83.0667527,94.1480575 L56.2750821,94.1480575 L32.8435758,70.5039241 L69.3453773,32.2519224 Z" fill="url(#linearGradient-1)" opacity="0.2"></path>
                                            <polygon id="Path-2" fill="#000000" opacity="0.049999997" points="69.3922914 32.4202615 32.8435758 70.5039241 54.0490008 16.1851325"></polygon>
                                            <polygon id="Path-21" fill="#000000" opacity="0.099999994" points="69.3922914 32.4202615 32.8435758 70.5039241 58.3683556 20.7402338"></polygon>
                                            <polygon id="Path-3" fill="url(#linearGradient-2)" opacity="0.099999994" points="101.428699 0 83.0667527 94.1480575 130.378721 47.0740288"></polygon>
                                        </g>
                                    </g>
                                </g>
                            </svg>
                        </span>
                        <h2 class="brand-text" data-i18n="会员中心"></h2>
                    </a>
                </li>
                <li class="nav-item nav-toggle">
                    <a class="nav-link modern-nav-toggle pr-0" data-toggle="collapse"><i
                            class="d-block d-xl-none text-primary toggle-icon font-medium-4" data-feather="x"></i><i
                            class="d-none d-xl-block collapse-toggle-icon font-medium-4  text-primary"
                            data-feather="disc" data-ticon="disc"></i></a>
                </li>
            </ul>
        </div>
        <div class="shadow-bottom"></div>
        <div class="main-menu-content">
            <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
                ${menus.map(item => {
                    const children = item.children || [];
                    const isCurr = (children.length === 0) && ((location.pathname + decodeURIComponent(location.search)) === item.link  || (item.extraLinks || []).includes(location.pathname));
                    
                    return `<li class="${isCurr ? 'active': ''} nav-item">
                        <a class="d-flex align-items-center" href="${item.link}">
                            <i data-feather="${item.icon}"></i><span class="menu-title text-truncate" data-i18n="${item.name}">${item.name}</span>
                        </a>
                        ${children.length > 0 ? `<ul class="menu-content">
                            ${children.map(child => {
                                const isCurr = (location.pathname + decodeURIComponent(location.search)) === child.link;
                                return `<li class="${isCurr ? 'active': ''}">
                                    <a class="d-flex align-items-center" href="${child.link}">
                                        <i data-feather="${child.icon}"></i>
                                        <span class="menu-item text-truncate" data-i18n="${child.name}">${child.name}</span>
                                    </a>
                                </li>`
                            }).join('\n')}
                        </ul>` : ''}
                    </li>`
                }).join('\n')}
            </ul>
        </div>
    </div>
    <!-- END: Main Menu-->
`)