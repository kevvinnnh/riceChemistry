function init_vars() {
    // 初始化变量
    jiaogeiwo.vars = {
        ...jiaogeiwo.vars,
        project: 'tianq5905', // 项目名称
        dir: 'public', // 接口类型 public | secure
        origin: '//cn2.caihongjianzhan.com' // 接口地址
    }
}

if ((typeof is_front !== 'undefined' && !!is_front) && (typeof is_server === 'undefined')) {
    init_vars();
} else {
    $(window).on('jiaogeiwo_load', function() {
        init_vars();
    })
}
