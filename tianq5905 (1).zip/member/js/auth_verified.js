function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('name');
    localStorage.removeItem('user');
    location.href = '/';
}

// 判断token
var token = localStorage.getItem('token');
var loginhref = '/member/auth/login.html';
// 微信登录 换掉appid,redirect_uri,state
// var loginhref = 'https://open.weixin.qq.com/connect/qrconnect?appid=wx32f68d744c45959d&redirect_uri=http://www.sanhaoxueshengsheying.com/member/auth/weixinlogin.html&response_type=code&scope=snsapi_login&state=legua4774#wechat_redirect'
// if (window.navigator.userAgent.toLowerCase().match(/MicroMessenger/i) == 'micromessenger') { // 微信内登录
//     loginhref = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx9f75006c629ada81&redirect_uri=http://www.sanhaoxueshengsheying.com/member/auth/weixinlogin.html&response_type=code&scope=snsapi_userinfo&state=legua4774#wechat_redirect';
// }
if (!token) {
    location.href = loginhref;
} else {
    var request = new XMLHttpRequest();
    request.open('GET', '//cn2.caihongjianzhan.com/api/admin/md/public/tianq5905/user-isLogin?token='+token, false); 
    request.send(null);
    if (request.status === 200) {
        const data = JSON.parse(request.responseText);
        if (data.status === 0) {
            var user = data.user;
            if (user.verifieds.some(item => item.status === '审核成功')) {
                localStorage.setItem('user', JSON.stringify(user));
            } else {
                // 还未实名, 需要先实名
                location.href = '/member/pages/user/verified.html';
            }
            
        } else {
            localStorage.setItem('lastpath', location.pathname + location.search);
            location.href = loginhref;
        }
    } else {
        localStorage.setItem('lastpath', location.pathname + location.search);
        location.href = loginhref;
    }
}